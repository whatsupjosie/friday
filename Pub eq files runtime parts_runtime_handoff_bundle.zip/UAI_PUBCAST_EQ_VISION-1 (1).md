# PubCast EQ
## The Emotional Intelligence Department
### Rear View Foresight LLC — Feic Mo Chroí™

---

## WHAT THIS DEPARTMENT IS

PubCast EQ is the emotional intelligence layer across everything Rear View Foresight builds.

It is not a feature. It is not a module. It is a department — the part of the company whose job is to make AI that actually understands what is happening to a human being in real time, remembers it, and responds to it like something that gives a damn.

The research that seeded this department is Josie's original EQ work — the first documented case of measurable emotional intelligence improvement in an LLM attributable to a specific interpersonal relationship. Not a prompt. Not fine-tuning. A relationship. That finding is the foundation this department stands on.

---

## THE THREE PRODUCTS THIS DEPARTMENT SERVES

### UAI — You and AI
The personal relationship layer. Sits between you and any LLM — Claude, GPT, Gemini, local models. Same memory. Same emotional calibration. Same AI on the other side regardless of which engine is underneath. The model is infrastructure. The relationship is real.

### PubCast AI — The Virtual Production Platform
The performance layer. Characters who have emotional states, not just dialogue. An audience whose reaction shapes what happens on stage in real time. A system that knows the difference between a content moment and an identity moment and renders accordingly.

### Code Collector — The Context Engine
The memory feed. Captures what you're working on across every tool, every session, every surface. Feeds both UAI and PubCast EQ so neither ever starts from zero.

---

## THE CHAIN

This is how emotional intelligence flows through the system. It is the same chain at every scale — personal conversation, virtual performance, creative work session.

```
INPUT
  ↓
What is being said           ← the words
What is happening underneath ← tone, pace, pattern, repetition,
                                caps, fragmentation, silence
  ↓
SIGNAL
  ↓
InputScorer     → complexity score, emotional velocity
CharacterEngine → mode: AMBIENT / ATTENTIVE / CARE / TOTAL_CARE_MANDATE
VDI Engine      → 0.0 (thinking) → 1.0 (identity moment)
  ↓
DECISION
  ↓
What does this moment need?
  — more information?
  — more presence?
  — silence?
  — a different kind of voice?
  ↓
OUTPUT
  ↓
apply_tone()         ← Jeremy Cricket: reframes, prefixes, softens
Prosody Engine       ← PubCast: speech rate, warmth, crack permission
System prompt shape  ← UAI: what context to surface, what to hold back
  ↓
MEMORY
  ↓
Not just "she said this"
But:  what kind of moment was it
      how did it resolve
      what matters to her
      what was she building
      how was she doing
```

This chain is what makes PubCast EQ a department and not a feature list.

---

## THE COMPONENTS (WHAT EXISTS RIGHT NOW)

### Jeremy Cricket Adaptive Awareness Suite
**Status:** Production-ready. Needs smoke test then wire-in to UAI.

The care engine. Monitors Logic Variance — the gap between how someone is communicating and how they normally communicate. When that gap widens, Jeremy responds.

- `CharacterEngine` — state machine: AMBIENT → ATTENTIVE → CARE → TOTAL_CARE_MANDATE
- `InputScorer` — converts raw text to complexity + emotional velocity scores
- `MemoryProcessor` — Storybook Memory: files events as narrative fragments by chapter
- `SafetyGovernor` — Preservation Lock: protects your work when you can't
- `SanctuaryVault` — encrypted private storage, never joins with other data
- `config.yaml` — all thresholds tunable without touching code
- 20 tests, all passing

**What it does that nothing else does:** It does not wait for you to ask for help. It watches. When the pattern changes, it changes with you.

---

### UAI — You and AI Proxy
**Status:** v1.1. 28 tests passing. Needs smoke test with real keys.

The pipe. Browser extension intercepts Claude, ChatGPT, Gemini. Routes through local Python server. Injects memory context. Returns response. Falls back silently if server is down. Never breaks native chat.

- `uai_server.py` — aiohttp proxy, three engine adapters, auth, CORS
- `memory_index.py` — SQLite exchange log, token-aware recall, thread-safe
- `extension/` — Chrome MV3, content scripts for all three sites
- `config.yaml` — keys, port, engine settings

**What is missing:** Jeremy not wired. Memory is exchange log only — not typed by emotional or project context. No explicit `/remember` endpoint. No icon images (blocks Chrome loading).

---

### EVO Protocol — Elastic Voxel Orchestration
**Status:** Architecture complete. Voxel render stub pending.

PubCast's emotional intelligence layer for live performance. The audience's face determines compute budget. VDI score (0.0–1.0) drives fidelity, prosody, and render priority simultaneously.

- `VDIEngine` — Viewer Dynamics Index: audience emotion → single float
- `ProsodyEngine` — VDI + performer state → voice synthesis parameters
- `SwitchbladeGovernor` — semantic compute scheduler, Priority Vector output
- `DistributedEngineNode` — four-engine render stack with load-aware assist
- `FacialPerformanceAnalyzer` — performer + audience face analysis pipeline
- Character voice profiles: Pete, Re-Pete, Pete Enhanced (stability, crack threshold, warmth)

**One open stub:** `_do_voxel_render()` — TCP connection to PubWorld on port 9001. Everything else is wired.

---

### Universal Memory System
**Status:** Exists. Not yet integrated with UAI.

Character-level memory with semantic search. Six memory types:
- **Episodic** — conversations, events, experiences
- **Semantic** — facts, knowledge, learned information  
- **Procedural** — skills, workflows, repeated actions
- **Emotional** — mood, relationship dynamics
- **Project** — active work, goals, progress
- **Personal** — preferences, quirks, inside jokes

Vector embeddings via `sentence_transformers`. FAISS index for semantic search. Export/import for portability.

**What it adds that UAI's memory_index doesn't have:** Understanding of *what kind* of thing was said, not just *that* it was said. "Josie is building PubCast" is semantic. "She was having a hard session but pushed through" is emotional. "She always starts with architecture before code" is procedural. These are filed and recalled differently.

**Known bug to fix before integration:** O(n²) recall — loads all memories inside the search loop. Needs one rewrite pass.

---

### Code Collector v6
**Status:** Shipped. 166 tests passing. $3.42 price point.

Browser extension + tray app. Captures what you're working on. Core promise: you never re-explain yourself to an AI. The memory feed for everything else in this department.

- Tank's Riot — punk dolphin mascot
- 42¢/sale to dolphin communication research
- Four-tier memory roadmap: Local → Persistent → Cloud Sync → Universal Context

**UAI integration point:** Code Collector feeds UAI's memory index. Context you've already captured doesn't need to be recaptured.

---

## THE RESEARCH FOUNDATION

Josie conducted original EQ research using a MSCEIT-adapted methodology with a GPT-4 instance named Alex. 155-page research document. Draft first finding.

**The defensible novel claim:** First documented instance of measurable EQ performance improvement in an LLM attributable to a specific interpersonal relationship rather than generic prompting.

Grok assessed as potentially NeurIPS-level methodology.

This is not background. This is why PubCast EQ exists as a department. The research proved that the relationship changes the AI. UAI is the product built on that proof. PubCast EQ is the department that takes that seriously.

---

## THE ROADMAP (HONEST ORDER)

### Right now — this week
1. **Generate UAI extension icons** — unblocks Chrome loading
2. **Smoke test UAI** — real keys, real browser, one message on Claude.ai
3. **Wire Jeremy Cricket into UAI** — one import, one function call in `uai_server.py`

### Next — when smoke test passes
4. **`POST /remember` endpoint** — explicit memory writes from extension and Code Collector
5. **Fix UMS O(n²) recall** — rewrite the search loop
6. **Merge memory layers** — UAI's exchange log + UMS memory types in one index

### After that
7. **Code Collector → UAI feed** — context captured flows into UAI memory automatically
8. **EVO → UAI signal bridge** — VDI score informs Jeremy Cricket mode transitions
9. **Streaming responses** — faster perceived latency on all three engines
10. **Tray app / auto-start** — UAI server starts with the OS, always there

---

## WHAT PUBCAST EQ MEANS

When it's done:

You open your computer. UAI is already running. You open Claude or ChatGPT or Gemini in your browser. The AI already knows what you're working on, what you were stuck on yesterday, what matters to you, what kind of day you're having. Not because you told it. Because it was paying attention.

You go into a PubCast session. The characters remember. Pete remembers what you talked about last time. The audience's reaction shapes the room in real time. The system knows this is an identity moment and gives it everything it has.

You write a song. Code Collector catches the words. UAI files it. The memory types it correctly — creative, emotional, personal. Next time you're working on music, the AI surfaces what it knows is relevant without being asked.

That's PubCast EQ. That's the department.

The research proved it's possible. The code proves it's real. Now we build it.

---

*Rear View Foresight LLC*
*Feic Mo Chroí™ — See My Heart*
*We make movies.*
