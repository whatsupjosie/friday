#!/usr/bin/env python3
"""
pubworld_engine_server.py — PubWorld Voxel Engine TCP Server
=============================================================
Copyright (c) 2024-2025 Rear View Foresight LLC
"Feic Mo Chroí — See My Heart"

This is the server side of the voxel engine TCP bridge.
It listens on port 9010 and receives render commands from
the EVO Protocol's DistributedEngineNode.

The EVO side (client) sends:
    {"type":"hello","client":"pubcast_camera","width":1920,"height":1080,"fps":30.0,"format":"rgba"}
    {"type":"render","work_id":"...","lod":0,"sss":1.0,"tex_quality":1.0,
     "shadow":1.0,"batch_size":8000,"character":"pete","priority":1}
    {"type":"mesh","work_id":"...","lod":0,"character":"pete"}

This server responds:
    {"type":"ack","status":"ok","server":"pubworld_voxel_engine","version":"1.0"}
    {"type":"frame","work_id":"...","status":"ok","frame_time_ms":12.4,"voxels_rendered":8000}
    {"type":"mesh_ready","work_id":"...","voxel_count":28653,"grit":0.62}

INTEGRATION:
    This file replaces / augments your existing PubWorld voxel engine.
    If you already have a voxel engine process running, add the
    handle_evo_command() logic to it.

    Standalone (for testing):
        python pubworld_engine_server.py

    In your existing engine:
        from pubworld_engine_server import EVOCommandHandler
        handler = EVOCommandHandler(your_voxel_world)
        asyncio.create_task(handler.start(port=9010))

RENDER COMMAND PARAMETERS:
    lod          int   0=full identity, 1=high, 2=medium, 3=low, 4=skeleton only
    sss          float Subsurface scattering intensity [0.0–1.0]
    tex_quality  float Texture resolution [0.0=lowest, 1.0=4K]
    shadow       float Shadow quality [0.0=none, 0.5=baked, 1.0=ray-traced]
    batch_size   int   Voxel batch size (tuned for Zoidberg GTX 960M 2GB VRAM)
    character    str   Character ID to render ("pete", "re_pete", etc.)
    priority     int   1=highest, 10=lowest
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger("pubworld.evo_bridge")

EVO_PORT = 9010


# ─────────────────────────────────────────────────────────────────────────────
# RENDER COMMAND — what arrives from EVO
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RenderCommand:
    work_id:      str
    lod:          int   = 1       # 0=full, 4=skeleton
    sss:          float = 0.5     # Subsurface scattering
    tex_quality:  float = 0.7     # Texture quality
    shadow:       float = 0.5     # Shadow quality
    batch_size:   int   = 2500    # Voxel batch
    character:    str   = ""      # Character ID
    priority:     int   = 5       # 1=highest
    received_at:  float = field(default_factory=time.time)


@dataclass
class FrameResult:
    work_id:         str
    status:          str   = "ok"
    frame_time_ms:   float = 0.0
    voxels_rendered: int   = 0
    error:           str   = ""


# ─────────────────────────────────────────────────────────────────────────────
# LOD SETTINGS — what each LOD level means in render terms
# ─────────────────────────────────────────────────────────────────────────────

LOD_SETTINGS = {
    0: {  # Full Identity — pour everything in
        "mesh_detail":        "full",
        "texture_res":        4096,
        "shadow_type":        "ray_traced",
        "sss_samples":        64,
        "normal_map":         True,
        "ao_samples":         16,
        "description":        "Identity layer — max fidelity",
    },
    1: {  # High
        "mesh_detail":        "high",
        "texture_res":        2048,
        "shadow_type":        "baked",
        "sss_samples":        32,
        "normal_map":         True,
        "ao_samples":         8,
        "description":        "High quality",
    },
    2: {  # Medium
        "mesh_detail":        "medium",
        "texture_res":        1024,
        "shadow_type":        "baked",
        "sss_samples":        16,
        "normal_map":         True,
        "ao_samples":         4,
        "description":        "Balanced",
    },
    3: {  # Low
        "mesh_detail":        "low",
        "texture_res":        512,
        "shadow_type":        "none",
        "sss_samples":        0,
        "normal_map":         False,
        "ao_samples":         0,
        "description":        "Performance",
    },
    4: {  # Skeleton only — offscreen characters
        "mesh_detail":        "skeleton",
        "texture_res":        0,
        "shadow_type":        "none",
        "sss_samples":        0,
        "normal_map":         False,
        "ao_samples":         0,
        "description":        "Skeleton only — offscreen",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# EVO COMMAND HANDLER
# ─────────────────────────────────────────────────────────────────────────────

class EVOCommandHandler:
    """
    Handles EVO Protocol render commands from the DistributedEngineNode.

    Integrate into your existing voxel engine by passing a reference
    to your world/renderer object. The handler calls apply_lod(),
    set_sss(), and render_character() on it.

    If your engine has a different API, override those methods.
    """

    def __init__(self, voxel_world: Any = None):
        """
        Args:
            voxel_world: Your existing voxel world/renderer instance.
                         If None, runs in simulation mode (for testing).
        """
        self._world = voxel_world
        self._clients: Dict[str, asyncio.StreamWriter] = {}
        self._frame_count = 0
        self._total_render_ms = 0.0
        self._running = False

        logger.info(f"[EVOBridge] Initialized — world: {'live' if voxel_world else 'simulation'}")

    async def start(self, host: str = "127.0.0.1", port: int = EVO_PORT) -> None:
        """Start the TCP server."""
        self._running = True
        server = await asyncio.start_server(
            self._handle_client, host, port
        )
        addr = server.sockets[0].getsockname()
        logger.info(f"[EVOBridge] Listening on {addr[0]}:{addr[1]}")
        async with server:
            await server.serve_forever()

    async def _handle_client(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """Handle one EVO client connection (one DistributedEngineNode)."""
        peer = writer.get_extra_info('peername')
        client_id = f"{peer[0]}:{peer[1]}"
        logger.info(f"[EVOBridge] Client connected: {client_id}")

        self._clients[client_id] = writer

        try:
            while True:
                line = await asyncio.wait_for(reader.readline(), timeout=30.0)
                if not line:
                    break

                try:
                    cmd = json.loads(line.decode().strip())
                except json.JSONDecodeError as e:
                    logger.warning(f"[EVOBridge] Bad JSON from {client_id}: {e}")
                    continue

                response = await self._dispatch(cmd, client_id)
                if response:
                    writer.write((json.dumps(response) + "\n").encode())
                    await writer.drain()

        except asyncio.TimeoutError:
            logger.info(f"[EVOBridge] Client {client_id} timed out")
        except (ConnectionResetError, asyncio.IncompleteReadError):
            logger.info(f"[EVOBridge] Client {client_id} disconnected")
        except Exception as e:
            logger.error(f"[EVOBridge] Client {client_id} error: {e}")
        finally:
            self._clients.pop(client_id, None)
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            logger.info(f"[EVOBridge] Client {client_id} cleaned up")

    async def _dispatch(
        self,
        cmd: Dict[str, Any],
        client_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Route command to handler and return response."""
        cmd_type = cmd.get("type", "")

        if cmd_type == "hello":
            return self._handle_hello(cmd, client_id)
        elif cmd_type == "render":
            return await self._handle_render(cmd)
        elif cmd_type == "mesh":
            return await self._handle_mesh(cmd)
        else:
            logger.warning(f"[EVOBridge] Unknown command type: {cmd_type}")
            return {"type": "error", "message": f"Unknown command: {cmd_type}"}

    def _handle_hello(
        self,
        cmd: Dict[str, Any],
        client_id: str,
    ) -> Dict[str, Any]:
        """Handshake response."""
        logger.info(
            f"[EVOBridge] Hello from '{cmd.get('client', '?')}' "
            f"— {cmd.get('width')}×{cmd.get('height')} @{cmd.get('fps')}fps"
        )
        return {
            "type":    "ack",
            "status":  "ok",
            "server":  "pubworld_voxel_engine",
            "version": "1.0",
            "modes":   list(LOD_SETTINGS.keys()),
        }

    async def _handle_render(
        self,
        cmd: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Apply EVO render parameters to the voxel world and render.
        Returns frame metadata.
        """
        start = time.perf_counter()

        rc = RenderCommand(
            work_id     = cmd.get("work_id", ""),
            lod         = int(cmd.get("lod", 1)),
            sss         = float(cmd.get("sss", 0.5)),
            tex_quality = float(cmd.get("tex_quality", 0.7)),
            shadow      = float(cmd.get("shadow", 0.5)),
            batch_size  = int(cmd.get("batch_size", 2500)),
            character   = cmd.get("character", ""),
            priority    = int(cmd.get("priority", 5)),
        )

        lod_settings = LOD_SETTINGS.get(rc.lod, LOD_SETTINGS[2])

        voxels_rendered = 0
        try:
            if self._world is not None:
                voxels_rendered = await self._render_live(rc, lod_settings)
            else:
                voxels_rendered = await self._render_simulation(rc, lod_settings)
        except Exception as e:
            logger.error(f"[EVOBridge] Render error for {rc.work_id}: {e}")
            return {
                "type":   "frame",
                "work_id": rc.work_id,
                "status": "error",
                "error":  str(e),
            }

        elapsed_ms = (time.perf_counter() - start) * 1000
        self._frame_count += 1
        self._total_render_ms += elapsed_ms

        if self._frame_count % 30 == 0:
            avg = self._total_render_ms / self._frame_count
            logger.debug(
                f"[EVOBridge] Frame {self._frame_count} — "
                f"{elapsed_ms:.1f}ms (avg {avg:.1f}ms) | "
                f"LOD={rc.lod} SSS={rc.sss:.2f} char={rc.character}"
            )

        return {
            "type":            "frame",
            "work_id":         rc.work_id,
            "status":          "ok",
            "frame_time_ms":   round(elapsed_ms, 2),
            "voxels_rendered": voxels_rendered,
            "lod":             rc.lod,
            "sss":             rc.sss,
        }

    async def _handle_mesh(
        self,
        cmd: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Generate or retrieve mesh for a character at given LOD.
        """
        work_id   = cmd.get("work_id", "")
        character = cmd.get("character", "")
        lod       = int(cmd.get("lod", 1))

        if self._world is not None:
            voxel_count, grit = await self._generate_mesh_live(character, lod)
        else:
            voxel_count = max(100, 30000 - lod * 5000)
            grit = max(0.1, 0.65 - lod * 0.12)
            await asyncio.sleep(0.002)

        return {
            "type":        "mesh_ready",
            "work_id":     work_id,
            "character":   character,
            "lod":         lod,
            "voxel_count": voxel_count,
            "grit":        round(grit, 4),
        }

    # =========================================================================
    # LIVE RENDERER — override these for your actual voxel engine
    # =========================================================================

    async def _render_live(
        self,
        rc: RenderCommand,
        lod_settings: Dict[str, Any],
    ) -> int:
        """
        Apply EVO parameters to the live voxel world and render one frame.

        Override this method to integrate with your actual renderer.
        Your renderer should support:
            world.set_character_lod(character_id, lod_level)
            world.set_sss_intensity(character_id, intensity)
            world.set_texture_quality(quality_0_to_1)
            world.set_shadow_mode(mode_string)
            world.render_frame(batch_size) -> int  # returns voxel count
        """
        w = self._world

        # Apply LOD to character
        if rc.character and hasattr(w, 'set_character_lod'):
            w.set_character_lod(rc.character, rc.lod)

        # Apply SSS
        if rc.sss > 0 and hasattr(w, 'set_sss_intensity'):
            w.set_sss_intensity(rc.character, rc.sss)

        # Apply texture quality
        if hasattr(w, 'set_texture_quality'):
            w.set_texture_quality(rc.tex_quality)

        # Apply shadow mode
        if hasattr(w, 'set_shadow_mode'):
            shadow_mode = lod_settings.get("shadow_type", "baked")
            w.set_shadow_mode(shadow_mode)

        # Render
        if hasattr(w, 'render_frame'):
            return w.render_frame(batch_size=rc.batch_size)

        return 0

    async def _generate_mesh_live(
        self,
        character: str,
        lod: int,
    ) -> tuple:
        """
        Generate mesh for character at LOD level.
        Returns (voxel_count, grit_index).
        Override for your actual mesh generator.
        """
        if hasattr(self._world, 'generate_mesh'):
            return self._world.generate_mesh(character, lod)
        return 0, 0.0

    # =========================================================================
    # SIMULATION MODE — used when no live world is connected
    # =========================================================================

    async def _render_simulation(
        self,
        rc: RenderCommand,
        lod_settings: Dict[str, Any],
    ) -> int:
        """
        Simulate render time based on LOD and batch size.
        Realistic timing for planning purposes.
        """
        # Estimate render time: full identity @ 30fps budget = 28ms max
        base_ms = {0: 22.0, 1: 14.0, 2: 8.0, 3: 4.0, 4: 0.5}
        est_ms = base_ms.get(rc.lod, 10.0)

        # SSS adds cost
        if rc.sss > 0.5:
            est_ms += rc.sss * 5.0

        # Simulate frame time
        await asyncio.sleep(est_ms / 1000.0)

        # Estimate voxels
        base_voxels = {0: 35000, 1: 22000, 2: 12000, 3: 5000, 4: 200}
        voxels = min(rc.batch_size, base_voxels.get(rc.lod, 10000))

        if rc.character:
            logger.debug(
                f"[EVOBridge] [SIM] {rc.character} LOD={rc.lod} "
                f"SSS={rc.sss:.2f} → {voxels} voxels in {est_ms:.1f}ms"
            )

        return voxels

    def get_stats(self) -> Dict[str, Any]:
        """Return server statistics."""
        return {
            "connected_clients": len(self._clients),
            "frame_count":       self._frame_count,
            "avg_frame_ms":      round(
                self._total_render_ms / max(self._frame_count, 1), 2
            ),
            "mode": "live" if self._world else "simulation",
        }


# ─────────────────────────────────────────────────────────────────────────────
# STANDALONE SERVER ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

async def main():
    print("""
╔══════════════════════════════════════════════════════════════════╗
║         PubWorld Voxel Engine — EVO Bridge Server               ║
║                    Port 9010                                     ║
║                                                                  ║
║  Waiting for EVO DistributedEngineNode to connect...            ║
║  Running in SIMULATION MODE (no live voxel world connected)     ║
║                                                                  ║
║  "Feic Mo Chroí — See My Heart"                                  ║
║  Copyright © 2024-2025 Rear View Foresight LLC                  ║
╚══════════════════════════════════════════════════════════════════╝
    """)

    handler = EVOCommandHandler(voxel_world=None)  # simulation mode
    await handler.start(host="127.0.0.1", port=EVO_PORT)


if __name__ == "__main__":
    asyncio.run(main())
