# PubCast with Avatar Foundry - Quick Start Guide

## 🚀 Getting Started

### 1. Install Dependencies

If you haven't already installed the required packages:

```bash
cd pubcast_with_avatar_foundry

# Install Python dependencies
pip install fastapi uvicorn numpy opencv-python scipy pillow pydantic --break-system-packages

# Optional but HIGHLY recommended for better face detection:
pip install mediapipe --break-system-packages
```

### 2. Start the Server

```bash
cd pubcast_with_avatar_foundry
uvicorn main:app --reload --port 8000
```

You should see:
```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
```

### 3. Open the Dressing Room

Navigate to: **http://localhost:8000/dressing**

## 🎭 Using the Avatar Foundry

### Step 1: Activate the Forge
1. You'll see three sections:
   - **Left**: Makeup mirror with neon avatar preview
   - **Center**: Full-length mirror with a white wooden stage
   - **Right**: Wardrobe panel
2. Click the **"⬡ Activate Forge"** button below the stage

### Step 2: The Foundry Appears
- The wooden stage fades out
- A sci-fi foundry platform materializes with:
  - Glowing cyan plasma grid floor
  - Floating MoCap skeleton
  - Dark void atmosphere
- The wardrobe panel switches to foundry controls

### Step 3: Upload Your Photo
1. Click the **BAKE** tab (should be active by default)
2. You'll see two photo slots:
   - **FACE** (Required): Upload a clear front-facing photo
   - **TORSO** (Optional): Not used yet, save for future
3. Upload methods:
   - **Drag and drop** your photo onto the FACE slot
   - **Click** the slot to open file picker

### Step 4: Choose Quality
Select one of three quality modes:
- **SURFACE** (48³): Fastest, lowest detail
- **TRACK** (64³): Balanced, recommended ⭐
- **ORBITAL** (96³): Highest detail, slowest

### Step 5: Optional Settings
- Toggle **"Fine Voxel Face"** for 2× resolution on the face mesh
  - Makes facial features more detailed
  - Slightly increases processing time

### Step 6: Forge Your Avatar
1. Click **"⬡ FORGE AVATAR"**
2. Watch the progress bar and forge log
3. Processing takes ~140-400ms depending on quality
4. Stats appear showing:
   - **Voxels**: Total voxel count
   - **Grit**: Detail/texture index (0-1)
   - **Mode**: Selected quality mode

### Step 7: Review Results
- Check the stats grid
- Your avatar data is:
  - Saved to `data/avatars/{your_user_id}/bakes/`
  - Broadcast via WebSocket as `avatar_baked` event
  - Sent to VoxelBridge as `AVATAR_UPDATE` command (if bridge running)

### Step 8: Return to Stage
Click **"← Return to Stage"** to exit foundry mode and return to the normal dressing room.

## 🎨 Exploring Other Tabs

### IDENTITY Tab
- Set your display name
- Choose gender (Neutral/Female/Male)
- Select mood: GROUNDED / ELEVATED / ORBITAL
- Pick a glow color from swatches
- Click "SAVE IDENTITY" to store settings

### RIG Tab
- Placeholder for CS-1 Chibi Skeleton
- Coming in future updates

## 📸 Photo Tips for Best Results

### Do's ✅
- Use a **clear, front-facing photo**
- Ensure **good lighting** (even, not too harsh)
- **Face clearly visible** (no obstructions)
- **Neutral or slight smile** works well
- **High resolution** (at least 512×512) recommended

### Don'ts ❌
- Avoid **side profiles** or angled faces
- Don't use **heavily filtered** photos
- Avoid **low light** or dark photos
- Don't use photos with **sunglasses** covering eyes
- Avoid **tilted or rotated** faces

### Best Results
For MediaPipe face detection to work optimally:
- Face should occupy ~60-80% of the image
- Eyes, nose, and mouth clearly visible
- Straight-on angle (within ±15 degrees)
- Good contrast between face and background

## 🔍 Checking If It Worked

### Browser Console
1. Open browser DevTools (F12)
2. Go to Console tab
3. Look for WebSocket messages:
   ```javascript
   {type: "avatar_baked", payload: {...}}
   ```

### Server Logs
Check your terminal running uvicorn for:
```
INFO:     127.0.0.1:XXXXX - "POST /api/avatars/me/bake HTTP/1.1" 200 OK
```

### File System
Check if bake was saved:
```bash
ls data/avatars/*/bakes/
# Should show: bake_1234567890.json
```

### API Endpoint
Test the status endpoint:
```bash
curl http://localhost:8000/api/avatars/me/bake/status
```

Should return:
```json
{
  "has_bake": true,
  "latest": {
    "avatar_id": "...",
    "mode": "TRACK",
    "resolution": 64,
    "voxel_count": 28653,
    "grit_index": 0.6234,
    ...
  }
}
```

## 🛠️ Troubleshooting

### "No face detected in image"
**Problem**: MediaPipe couldn't find a face in your photo

**Solutions**:
1. Make sure face is clearly visible and front-facing
2. Try a different photo with better lighting
3. Ensure face occupies most of the image
4. If MediaPipe not installed, it falls back to center-crop (less accurate)

### Processing takes too long
**Problem**: Bake is slow or times out

**Solutions**:
1. Use **SURFACE** or **TRACK** mode instead of ORBITAL
2. Turn off "Fine Voxel Face" toggle
3. Use a smaller photo (resize to 1024×1024 before upload)
4. Check CPU usage - sculptor is CPU-intensive

### Foundry button doesn't work
**Problem**: Nothing happens when clicking "Activate Forge"

**Solutions**:
1. Check browser console for JavaScript errors
2. Make sure you're using a modern browser (Chrome, Firefox, Safari, Edge)
3. Clear browser cache and reload page
4. Check if `dressing.js` loaded correctly in Network tab

### Stats don't appear after bake
**Problem**: Progress bar completes but no stats shown

**Solutions**:
1. Check browser console for errors
2. Verify API response in Network tab
3. Check server logs for Python exceptions
4. Try refreshing the page and baking again

### Bridge warnings in server logs
**Problem**: Seeing "Could not send avatar update to bridge"

**This is normal!** The warning means:
- VoxelBridge C++ renderer isn't running
- Bake still succeeds and saves correctly
- Avatar data is stored and can be used later
- To use the 3D engine, you'd need to run the C++ renderer separately

## 🎯 What Happens During a Bake

Here's the full pipeline when you click "FORGE AVATAR":

1. **Upload**: Photo sent to `/api/avatars/me/bake` endpoint
2. **Save Temp**: File saved to `data/temp/{user_id}/face_{timestamp}.jpg`
3. **Load Image**: OpenCV loads the image
4. **EXIF Fix**: Rotates image based on EXIF orientation data
5. **Center Crop**: Crops to square aspect ratio
6. **CLAHE**: Applies adaptive histogram equalization in LAB colorspace
7. **Bilateral Filter**: Edge-preserving smoothing
8. **Face Detection**: MediaPipe FaceMesh finds facial landmarks
9. **Face Crop**: Extracts face region with padding
10. **Color Sampling**: Samples skin color (forehead) and hair color (top)
11. **Grit Map**: Creates sigmoid-normalized texture map from grayscale
12. **Extrude**: Broadcasts 2D grit map to 3D voxel volume
13. **Erosion Shell**: Creates hollow shell to reduce voxel count
14. **Pack**: Encodes voxels as hex string (8 voxels per byte)
15. **Save**: Stores result to `data/avatars/{user_id}/bakes/`
16. **Broadcast**: Sends `avatar_baked` WebSocket event
17. **Bridge**: Sends `AVATAR_UPDATE` command to VoxelBridge
18. **Return**: Sends preview (without hex blob) to client
19. **Cleanup**: Deletes temp file
20. **Display**: Shows stats in UI

Total time: **~140ms** for TRACK mode (64³ voxels)

## 📊 Understanding the Stats

### Voxels
The total number of "filled" voxels in your avatar mesh.
- **SURFACE mode**: 8,000 - 15,000 voxels typical
- **TRACK mode**: 20,000 - 40,000 voxels typical
- **ORBITAL mode**: 50,000 - 90,000 voxels typical
- **Fine Face**: Adds ~5,000 - 10,000 extra voxels to face

### Grit Index
A measure of texture/detail (0-1):
- **0.0 - 0.3**: Low detail, smooth surfaces
- **0.3 - 0.6**: Medium detail, typical faces
- **0.6 - 1.0**: High detail, lots of texture

Higher grit = more facial features, wrinkles, texture captured

### Mode
The quality setting you selected:
- **SURFACE**: Fast iteration, lower fidelity
- **TRACK**: Balanced quality and speed
- **ORBITAL**: Maximum detail and fidelity

## 🔐 Data Privacy

All uploaded photos:
- Are saved temporarily during processing
- Are **deleted immediately** after bake completes
- Are **never stored permanently** on the server
- Only the voxel data is saved (no original photo)

Bake results are stored per-user in:
```
data/avatars/{user_id}/bakes/bake_{timestamp}.json
```

## 🌟 Pro Tips

1. **Start with TRACK mode** to find good photos, then re-bake with ORBITAL
2. **Use Fine Voxel Face** for close-up shots or when facial detail matters
3. **Check the grit index** - if too low, try a photo with more texture
4. **SURFACE mode** is great for quick testing and iteration
5. **Lighting matters** - even, diffused light gives best results
6. **Multiple bakes** are fine - each is saved with timestamp
7. **Check bake history** via `/api/avatars/me/bake/status` endpoint

## 🎪 Have Fun!

The Avatar Foundry is a powerful tool for creating personalized voxel avatars from photos. Experiment with different photos, quality settings, and options to find what works best for your use case.

Happy forging! ⬡

---

**Need Help?**
- Check `AVATAR_FOUNDRY_INTEGRATION.md` for technical details
- Review server logs for error messages
- Open browser DevTools Console for client-side errors
- Check `data/avatars/{user_id}/bakes/` for saved results
