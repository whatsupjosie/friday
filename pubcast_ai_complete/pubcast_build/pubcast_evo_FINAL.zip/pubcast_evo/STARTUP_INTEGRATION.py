"""
PUBCAST AI STARTUP SEQUENCE — EVO INTEGRATION
==============================================
Add this to main.py / main_integrated.py

REQUIRED ORDER:
1. Create FastAPI app
2. Start existing Phase-1 components (Hub, Cameras, Recording, Avatar, FFmpeg)
3. Create DistributedEngineNode (twin engine)
4. Create LLMBridge from LLMFramework
5. setup_evo() — starts E-Pete, wires everything
6. Create RecordingEVOBridge — wires recording ↔ EVO
7. Mount EVO router
8. Start uvicorn

Example (add to main.py lifespan/startup):
"""

# ── In main.py ────────────────────────────────────────────────────────────────
STARTUP_INTEGRATION_CODE = """
# Add these imports at top of main.py:
from modules.hub_evo import setup_evo, get_evo_router
from modules.llm_bridge import LLMBridge
from modules.recording_evo_bridge import RecordingEVOBridge
from distributed_engine import create_twin_engine

# In your lifespan/startup handler:
@asynccontextmanager
async def lifespan(app: FastAPI):
    # --- Existing Phase-1 startup ---
    await hub.initialize()
    await camera_manager.initialize_all_cameras()
    await camera_manager.start_monitoring()
    # ... recording service, avatar, ffmpeg ...

    # --- EVO Protocol startup ---
    # 1. Start distributed engine
    twin_engine = create_twin_engine("twin_engine")
    await twin_engine.start()

    # 2. Create LLM bridge from existing framework
    from modules.llm_framework import LLMFramework
    llm_fw   = LLMFramework()  # or however it's initialized
    llm_bridge = LLMBridge(llm_fw)

    # 3. Setup EVO (starts E-Pete, Pete, Switchblade, VDI)
    evo = await setup_evo(
        engine_node     = twin_engine,
        camera_manager  = camera_manager,
        llm_backend     = llm_bridge,
        studio_model    = "gemma:2b",    # Match your Ollama model names
        architect_model = "gemma:7b",    # Match your Ollama model names
    )

    # 4. Wire recording ↔ EVO
    recording_bridge = RecordingEVOBridge(
        evo       = evo,
        recording = recording_service,
        avatar    = avatar_system,
    )

    # 5. Mount EVO router
    app.include_router(get_evo_router(evo), prefix="/api/evo")

    yield  # App is running

    # --- Shutdown ---
    await evo.stop()
    await twin_engine.stop()
    await camera_manager.stop_monitoring()
"""
