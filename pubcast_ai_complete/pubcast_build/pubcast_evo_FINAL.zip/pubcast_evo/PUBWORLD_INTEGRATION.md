# PubWorld Walking Map Integration - Complete

## 🗺️ Overview

The Avatar Foundry is now fully integrated into PubCast's PubWorld walking map system! Users can navigate through the immersive 2D walking game and enter the Dressing Room from the Green Room.

## 🎮 Walking Map Structure

PubWorld is a parallax walking game with multiple interconnected rooms. Each room has:
- **Background image** - Drawn artwork with perspective
- **Walk paths** - Y-axis depth ranges (walking toward/away from camera)
- **Doors** - Portals to other rooms with glowing indicators
- **Hotspots** - Interactive objects (chairs, desks, props)
- **Minimap** - Top-down navigation reference

### Current Room Map

```
┌─────────────────────────────────────────────────────────┐
│                    LOBBY (Entry)                         │
│                         ↓                                │
│                    HALLWAY                               │
│         ↙            ↓              ↘                    │
│   WRITERS ROOM   GREEN ROOM    CONTROL ROOM              │
│                      ↓                                   │
│              Multiple Doors:                             │
│    ┌─────────────────┼─────────────────┐               │
│    │                 │                 │               │
│ DIRECTOR'S      DRESSING ROOM      STUDIO A            │
│   FOYER         (Avatar Foundry)   (Live Stage)        │
│    │                                  │                │
│ PUBWORLD 3D                      STUDIO SETS           │
│ (Future)                         (Permanent Sets)      │
│                                                         │
│  Also accessible: VORTEX BAR (from Green Room right)   │
└─────────────────────────────────────────────────────────┘
```

## 🚪 Dressing Room Integration

### From Green Room → Dressing Room

**Location**: Left side of the Green Room (near the cabinet)

**How it works**:
1. User enters Green Room via any route (Hallway, Studio, Control Room, etc.)
2. Walks to the **left side** of the room (near bottom-left area)
3. A door appears with glowing gold border when player approaches
4. Door labeled: **"DRESSING ROOM"**
5. Press **E** or **ENTER** key to activate
6. Page redirects to `/dressing` (full Avatar Foundry interface)

**Door Position**:
- `left: 12%` (far left side)
- `bottom: 38%` (mid-height, near the cabinet)
- `width: 42px`, `height: 58px`
- `edge: 'left'` (door faces left wall)

### From Dressing Room → Green Room

**Location**: Top-right header of Dressing Room

**How it works**:
1. Click **"← GREEN ROOM"** button in top-right header
2. Returns to index page with hash: `/#pubworld-greenroom`
3. Auto-opens PubWorld view
4. Auto-navigates to Green Room
5. Player spawns at center of room

**Visual Design**:
- Warm accent color button (matches dressing room aesthetic)
- Hover effect: fills with accent color
- Always visible in header (non-intrusive)

## 🎨 Visual Experience

### In PubWorld (Green Room)
- **Cursor**: Custom gold circular cursor (replaces default)
- **Door Glow**: Pulsing gold border when player is near
- **Label**: "DRESSING ROOM" text fades in when in range
- **Interaction**: Press **E** or **ENTER** when door glows
- **Transition**: Black fade overlay (400ms)

### In Dressing Room
- **Three-section layout**: Makeup mirror (left), Full-length mirror with stage (center), Wardrobe (right)
- **Back button**: Subtle but clear "← GREEN ROOM" link
- **Seamless return**: Direct navigation back to walking map

## 🔧 Technical Implementation

### 1. Room Definition (pubworld.html)

```javascript
dressing: {
  bg: null,                     // No background (external page)
  name: 'DRESSING ROOM',
  externalLink: '/dressing',    // Redirect to actual page
  walkPath: { minY:62, maxY:80, minScale:0.8, maxScale:1.0 },
  mmDot: {cx:57, cy:49},        // Minimap position
  doors: [
    { 
      id: 'dd-greenroom', 
      label: '← GREEN ROOM', 
      left: 50, 
      bottom: 18, 
      width: 65, 
      height: 85, 
      target: 'greenroom', 
      edge: 'bottom' 
    }
  ],
  hotspots: []
}
```

### 2. Green Room Door Addition

```javascript
greenroom: {
  // ... existing config ...
  doors: [
    // ... existing doors ...
    { 
      id: 'dgr-dressing', 
      label: 'DRESSING ROOM', 
      left: 12,              // Far left
      bottom: 38,            // Mid-height
      width: 42, 
      height: 58, 
      target: 'dressing',    // Links to dressing room
      edge: 'left' 
    }
  ]
}
```

### 3. External Link Handling

In `goToRoom()` function:

```javascript
// Handle external page links (like dressing room)
if (room.externalLink) {
  window.location.href = room.externalLink;
  return;
}
```

### 4. Return Navigation (dressing.html)

```html
<header class="top-bar">
  <div class="logo">PubCast Dressing Room</div>
  <div class="status">
    <!-- ... status info ... -->
    <a href="/#pubworld-greenroom" class="back-to-world-btn">
      ← GREEN ROOM
    </a>
  </div>
</header>
```

### 5. Hash-based Auto-Navigation (index.html)

```javascript
// Check for hash on page load to auto-open PubWorld
window.addEventListener('DOMContentLoaded', () => {
  const hash = window.location.hash;
  if (hash === '#pubworld-greenroom') {
    setTimeout(() => {
      document.querySelector('.pubworld-btn')?.click();
      setTimeout(() => {
        if (window.pubworldGoToRoom) {
          window.pubworldGoToRoom('greenroom', 50, 74);
        }
      }, 500);
    }, 100);
    history.replaceState(null, null, ' ');
  }
});

// Expose goToRoom globally
window.pubworldGoToRoom = goToRoom;
```

## 🎯 User Flow

### Complete Journey

1. **Start**: User loads PubCast at `/` (index.html)
2. **Enter PubWorld**: Click "PubWorld" nav button
3. **Navigate Map**: Use WASD/Arrow keys to walk through rooms
4. **Find Green Room**: Via Hallway, Studio, or Control Room
5. **Locate Dressing Room**: Walk to **left side** of Green Room
6. **See Door Glow**: Approach door, watch gold border pulse
7. **Enter**: Press **E** or **ENTER** key
8. **Page Transition**: Black fade, redirects to `/dressing`
9. **Avatar Foundry**: Full interface loads
   - Makeup mirror (left) with presets
   - Full-length mirror with stage/foundry platform (center)
   - Wardrobe panel with customizer/foundry controls (right)
10. **Activate Foundry**: Click "⬡ Activate Forge" on stage
11. **Bake Avatar**: Upload photo, set quality, forge voxels
12. **Return**: Click "← GREEN ROOM" in header
13. **Back to Map**: Auto-returns to Green Room in PubWorld
14. **Continue Exploring**: Walk to other rooms

## 🗺️ Navigation Map Reference

### From Any Room to Dressing Room

```
START: Anywhere in PubWorld
  ↓
Navigate to GREEN ROOM (via doors/hallways)
  ↓
Walk to LEFT SIDE (near cabinet, x ≈ 12%)
  ↓
Approach DRESSING ROOM door (glows gold)
  ↓
Press E or ENTER
  ↓
ARRIVE: Dressing Room (/dressing)
```

### From Dressing Room to Anywhere

```
START: Dressing Room
  ↓
Click "← GREEN ROOM" button (top-right)
  ↓
Return to index with hash
  ↓
PubWorld auto-opens
  ↓
Auto-navigates to GREEN ROOM
  ↓
Player spawns at center (50%, 74%)
  ↓
Walk to any connected room:
  - HALLWAY (bottom edge)
  - WRITERS ROOM (back wall left)
  - STUDIO (back wall center)
  - CONTROL ROOM (back wall right)
  - VORTEX BAR (right wall)
  - DIRECTOR'S FOYER (left wall)
```

## 🎮 Controls Reference

### In PubWorld (Walking Map)
- **Movement**: W/A/S/D or Arrow Keys
- **Interact**: E or Enter (when near door/hotspot)
- **Back**: Escape (exits first-person views)
- **Cursor**: Mouse (custom gold circle)

### In Dressing Room
- **Return to Map**: Click "← GREEN ROOM" button
- **Activate Foundry**: Click "⬡ Activate Forge"
- **Upload Photo**: Drag-and-drop or click photo slots
- **Select Quality**: Click SURFACE/TRACK/ORBITAL buttons
- **Forge Avatar**: Click "⬡ FORGE AVATAR"
- **Exit Foundry**: Click "← Return to Stage"

## 🔍 Room Details

### Green Room Features
**Dimensions**: Wide panoramic room with depth perspective

**Interactive Elements**:
- Curved sectional couch (2 sit spots)
- Coffee table (walk-behind)
- Cabinet on left wall (walk-behind)
- Stairs on far left (descend deeper)

**Doors** (7 total):
1. Writers Room (back wall left)
2. Studio (back wall center)
3. Control Room (back wall right)
4. Vortex Bar (right wall)
5. Hallway (bottom edge)
6. Director's Foyer (left wall)
7. **Dressing Room** (left wall, near cabinet) ⭐ **NEW**

**Walk Lanes** (objects you can walk behind):
- Behind curved couch (mid-depth, center)
- Behind coffee table (mid-foreground)
- Behind left cabinet (mid-depth, left side)

### Dressing Room Features
See `AVATAR_FOUNDRY_INTEGRATION.md` for complete details.

**Key Areas**:
- Makeup Mirror (left) - Neon avatar preview
- Full-length Mirror (center) - White wooden stage
- Foundry Platform (center, activated) - Sci-fi forge
- Wardrobe Panel (right) - Controls and tabs

## 🎨 Aesthetic Integration

### PubWorld Style
- **Color Palette**: Gold (#c9a84c), Accent cyan (#00e5cc)
- **Font**: Cinzel serif (elegant, vintage broadcast)
- **Atmosphere**: Dark, warm, retro-futurist
- **UI**: HUD overlays, scanlines, custom cursor

### Dressing Room Style
- **Default**: Warm cream (#f5f1e8), white wood (#faf8f3)
- **Foundry**: Dark void (#0a0a0f), plasma cyan (#00d4ff)
- **Font**: Rajdhani (modern, clean), Orbitron (headers)
- **Atmosphere**: Dual-mode (cozy ↔ sci-fi)
- **UI**: Clean panels, smooth transitions

### Transition Smoothness
- PubWorld → Dressing: Black fade (400ms) + page load
- Dressing → PubWorld: Instant redirect + auto-navigation
- Visual continuity maintained through color harmony

## 📝 Files Modified

### 1. `static/pubworld.html`
**Changes**:
- Added `externalLink` property to dressing room definition
- Added external link redirect in `goToRoom()` function
- Added dressing room door to green room door list

**Lines changed**: ~10 lines

### 2. `static/index.html`
**Changes**:
- Exposed `window.pubworldGoToRoom` global function
- Added hash detection on DOMContentLoaded
- Auto-opens PubWorld and navigates to green room on hash

**Lines changed**: ~20 lines

### 3. `static/dressing.html`
**Changes**:
- Added "← GREEN ROOM" back button in header
- Links to `/#pubworld-greenroom` for auto-navigation

**Lines changed**: 1 line

### 4. `static/dressing.css`
**Changes**:
- Added `.back-to-world-btn` styles
- Warm accent color, hover effects

**Lines changed**: ~20 lines

## ✅ Testing Checklist

### PubWorld → Dressing Room
- [ ] Can navigate to Green Room from any starting room
- [ ] Dressing room door appears on left side near cabinet
- [ ] Door glows gold when player approaches
- [ ] "DRESSING ROOM" label appears when in range
- [ ] Press E/Enter activates door
- [ ] Black fade transition occurs
- [ ] Redirects to `/dressing` page
- [ ] Dressing room loads correctly

### Dressing Room → PubWorld
- [ ] "← GREEN ROOM" button visible in header
- [ ] Button has proper styling (accent color)
- [ ] Hover effect works (fills with accent)
- [ ] Click redirects to `/#pubworld-greenroom`
- [ ] Index page loads
- [ ] PubWorld auto-opens
- [ ] Green room auto-loads
- [ ] Player spawns at center position

### Avatar Foundry Functionality
- [ ] All dressing room features work (mirrors, presets)
- [ ] Foundry activation works (stage → platform)
- [ ] Photo upload works (drag-and-drop, click)
- [ ] Quality selection works (SURFACE/TRACK/ORBITAL)
- [ ] Bake process works (progress, stats)
- [ ] Return to stage works (platform → stage)
- [ ] Back button still visible during all modes

## 🚀 Future Enhancements

### Potential Additions

1. **Visual Continuity**
   - Show avatar preview in PubWorld (floating orb above player)
   - Display forged avatar stats in Green Room
   - Persistent avatar data across sessions

2. **Additional Integrations**
   - Writing Nook (first-person desk view) accessible from Dressing Room
   - Avatar Gallery wall in Green Room showing all forged avatars
   - Quick-switch between rooms via minimap clicks

3. **Enhanced Navigation**
   - Minimap shows all visited rooms
   - Breadcrumb trail of recent rooms
   - Fast travel system for known locations

4. **Multiplayer Features**
   - See other players' avatars in PubWorld
   - Avatar showcase in Green Room lounge
   - Collaborative avatar creation sessions

5. **Story Integration**
   - Quest to forge all avatar types
   - NPC interactions in Green Room
   - Unlock special rooms via avatar achievements

## 🎯 Summary

The Avatar Foundry is now seamlessly integrated into PubCast's PubWorld walking map! Users can:

✅ Navigate through immersive 2D parallax rooms
✅ Find the Dressing Room door in the Green Room
✅ Enter the full Avatar Foundry interface
✅ Upload photos and forge voxel avatars
✅ Return to the walking map with one click
✅ Continue exploring other rooms

The integration maintains visual continuity, provides smooth transitions, and creates a cohesive exploration experience. The dressing room feels like a natural part of the PubWorld environment while offering its own unique interface and functionality.

**Status**: ✅ **COMPLETE AND FULLY INTEGRATED**
