"""
PubCast AI — EVO Protocol
=========================
Elastic Voxel Orchestration with E-Pete governance layer.

Copyright (c) 2024-2025 Rear View Foresight LLC
"Feic Mo Chroí — See My Heart"

Quick start:
    from pubcast_evo.evo_integration import EVOOrchestrator
    evo = EVOOrchestrator(active_character="pete")
"""
from .evo_integration   import EVOOrchestrator, EVOTick
from .epete             import EPete, InferenceTask, TaskType, InferenceModel
from .pete              import PeteCharacter
from .vdi_engine        import VDIEngine, VDIReport, VDISignals, VoiceMode
from .prosody_engine    import ProsodyEngine, SynthesisParams, EmotionalState
from .switchblade_governor import SwitchbladeGovernor, SceneState, PriorityVector
from .voice_characters  import get_character_profile, list_characters

__version__ = "1.0.0"
__all__ = [
    "EVOOrchestrator", "EVOTick",
    "EPete", "InferenceTask", "TaskType", "InferenceModel",
    "PeteCharacter",
    "VDIEngine", "VDIReport", "VDISignals", "VoiceMode",
    "ProsodyEngine", "SynthesisParams", "EmotionalState",
    "SwitchbladeGovernor", "SceneState", "PriorityVector",
    "get_character_profile", "list_characters",
]
