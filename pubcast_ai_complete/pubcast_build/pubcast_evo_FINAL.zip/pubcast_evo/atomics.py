"""
modules/atomics.py — Atomic mmap Operations
=============================================
Replaces the undefined Atomics.store()/Atomics.load() references
in bulletproof_twin_engine_bridge.py.

Provides struct-based atomic reads/writes into mmap memory regions.
Not truly atomic at the hardware level, but safe for single-process
IRM data reads/writes on the asyncio event loop.
"""
import struct
import mmap
from typing import Union


# Format codes for each supported type
_FORMAT_MAP = {
    float: 'f',    # 32-bit float
    int:   'I',    # 32-bit unsigned int
    bool:  'B',    # 8-bit unsigned (0 or 1)
}

# Extended format map keyed by size
_DOUBLE_FORMAT = 'd'   # 64-bit float (for watchdog timestamp)
_UINT64_FORMAT = 'Q'   # 64-bit unsigned int


class Atomics:
    """
    Atomic-style read/write operations for mmap memory regions.
    Uses struct.pack_into / struct.unpack_from for consistent byte layout.
    """

    @staticmethod
    def store(memory: mmap.mmap, offset: int, value: Union[float, int, bool]) -> None:
        """Store a value at offset in mmap memory."""
        if offset == 0 and isinstance(value, int) and value > 2**32:
            # watchdog_timestamp — 64-bit unsigned
            struct.pack_into('=Q', memory, offset, int(value))
        elif isinstance(value, float):
            struct.pack_into('=f', memory, offset, value)
        elif isinstance(value, bool):
            struct.pack_into('=B', memory, offset, int(value))
        elif isinstance(value, int):
            struct.pack_into('=I', memory, offset, value)
        else:
            raise TypeError(f"Atomics.store: unsupported type {type(value)}")

    @staticmethod
    def load(memory: mmap.mmap, offset: int, fmt: str = 'f') -> Union[float, int]:
        """
        Load a value from offset in mmap memory.
        fmt: struct format char ('f'=float32, 'I'=uint32, 'Q'=uint64, 'B'=uint8)
        """
        size = struct.calcsize(f'={fmt}')
        result = struct.unpack_from(f'={fmt}', memory, offset)
        return result[0]

    @staticmethod
    def store_double(memory: mmap.mmap, offset: int, value: float) -> None:
        """Store a 64-bit float (double) at offset."""
        struct.pack_into('=d', memory, offset, value)

    @staticmethod
    def store_uint64(memory: mmap.mmap, offset: int, value: int) -> None:
        """Store a 64-bit unsigned int at offset."""
        struct.pack_into('=Q', memory, offset, value)
