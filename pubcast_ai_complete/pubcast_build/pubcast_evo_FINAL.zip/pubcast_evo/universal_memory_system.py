"""
modules/universal_memory_system.py — Universal Memory System
=============================================================
Copyright (c) 2024-2025 Rear View Foresight LLC
"Feic Mo Chroí — See My Heart"

Pete remembers. Not everything — the right things.

Cross-session persistent memory backed by SQLite.
Stores conversation turns, user preferences, emotional patterns,
and topic history so Pete can reference past conversations naturally.

Three memory tiers:
    WORKING     — Current session (in-memory, fast)
    EPISODIC    — Conversation history (SQLite, persists)
    SEMANTIC    — Distilled facts about user (SQLite, persists)

Public API:
    UniversalMemorySystem
        .remember(turn: MemoryTurn) -> None
        .recall(query: str, limit: int) -> List[MemoryTurn]
        .get_user_context() -> UserContext
        .distill_session() -> None        # Call on session end
        .get_pete_briefing() -> str       # Pete's context summary
"""
from __future__ import annotations

import json
import logging
import re
import sqlite3
import time
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

DB_PATH = Path("data/pubcast_memory.db")


# ─────────────────────────────────────────────────────────────────────────────
# DATA TYPES
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class MemoryTurn:
    """One conversation turn to be remembered."""
    role:       str         # "user" | "pete"
    content:    str
    vdi_score:  float       = 0.5
    voice_mode: str         = "mixed"
    session_id: str         = ""
    timestamp:  float       = field(default_factory=time.time)
    importance: float       = 0.5   # 0=forgettable, 1=critical


@dataclass
class SemanticFact:
    """A distilled fact about the user or session."""
    category:   str         # "preference" | "topic" | "emotion" | "name" | "project"
    key:        str
    value:      str
    confidence: float       = 1.0
    last_seen:  float       = field(default_factory=time.time)
    times_seen: int         = 1


@dataclass
class UserContext:
    """Aggregated user context for Pete's briefing."""
    recent_topics:      List[str]       = field(default_factory=list)
    emotional_pattern:  str             = "neutral"  # dominant pattern
    avg_vdi:            float           = 0.5
    session_count:      int             = 0
    facts:              List[SemanticFact] = field(default_factory=list)
    last_session_summary: str           = ""


# ─────────────────────────────────────────────────────────────────────────────
# DATABASE
# ─────────────────────────────────────────────────────────────────────────────

SCHEMA = """
CREATE TABLE IF NOT EXISTS memory_turns (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT    NOT NULL,
    role        TEXT    NOT NULL,
    content     TEXT    NOT NULL,
    vdi_score   REAL    DEFAULT 0.5,
    voice_mode  TEXT    DEFAULT 'mixed',
    importance  REAL    DEFAULT 0.5,
    timestamp   REAL    NOT NULL
);

CREATE TABLE IF NOT EXISTS semantic_facts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    category    TEXT    NOT NULL,
    key         TEXT    NOT NULL,
    value       TEXT    NOT NULL,
    confidence  REAL    DEFAULT 1.0,
    last_seen   REAL    NOT NULL,
    times_seen  INTEGER DEFAULT 1,
    UNIQUE(category, key)
);

CREATE TABLE IF NOT EXISTS session_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT    UNIQUE NOT NULL,
    started_at  REAL    NOT NULL,
    ended_at    REAL,
    avg_vdi     REAL,
    peak_mode   TEXT,
    summary     TEXT
);

CREATE INDEX IF NOT EXISTS idx_turns_session  ON memory_turns(session_id);
CREATE INDEX IF NOT EXISTS idx_turns_time     ON memory_turns(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_facts_category ON semantic_facts(category);
"""


class UniversalMemorySystem:
    """
    Cross-session persistent memory for PubCast.
    Pete reads this on startup to know who she's talking to.
    """

    def __init__(
        self,
        db_path:        Path    = DB_PATH,
        session_id:     str     = "",
        working_limit:  int     = 50,
        episodic_limit: int     = 500,
    ):
        self.db_path        = db_path
        self.session_id     = session_id or f"session_{int(time.time())}"
        self.working_limit  = working_limit
        self.episodic_limit = episodic_limit

        # Working memory — current session
        self._working: List[MemoryTurn] = []
        self._session_start = time.time()
        self._vdi_samples:  List[float] = []
        self._mode_counts:  Dict[str, int] = {}

        # Initialize DB
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
        self._log_session_start()

        logger.info(f"[Memory] Session {self.session_id} started")

    # =========================================================================
    # PUBLIC API
    # =========================================================================

    def remember(self, turn: MemoryTurn) -> None:
        """Store a conversation turn in working memory and persist it."""
        turn.session_id = self.session_id

        # Working memory
        self._working.append(turn)
        if len(self._working) > self.working_limit:
            self._working.pop(0)

        # Track VDI
        self._vdi_samples.append(turn.vdi_score)
        self._mode_counts[turn.voice_mode] = (
            self._mode_counts.get(turn.voice_mode, 0) + 1
        )

        # Persist to SQLite
        self._insert_turn(turn)

        # Extract semantic facts inline for high-importance turns
        if turn.importance >= 0.8 and turn.role == "user":
            self._extract_facts_inline(turn)

    def recall(
        self,
        query:          str     = "",
        limit:          int     = 10,
        role_filter:    Optional[str] = None,
        min_importance: float   = 0.0,
    ) -> List[MemoryTurn]:
        """
        Recall recent turns, optionally filtered.
        Simple recency + importance ranking — no vector search.
        For now: returns most recent turns matching criteria.
        """
        # First check working memory
        working_results = [
            t for t in reversed(self._working)
            if (role_filter is None or t.role == role_filter)
            and t.importance >= min_importance
            and (not query or query.lower() in t.content.lower())
        ]

        if len(working_results) >= limit:
            return working_results[:limit]

        # Supplement from episodic (SQLite)
        needed = limit - len(working_results)
        episodic = self._query_turns(
            query=query,
            role_filter=role_filter,
            min_importance=min_importance,
            limit=needed * 2,
        )

        # Deduplicate (working memory already has recent turns)
        working_ids = {id(t) for t in working_results}
        working_contents = {t.content for t in working_results}
        episodic_new = [t for t in episodic if t.content not in working_contents]

        combined = working_results + episodic_new
        return combined[:limit]

    def get_user_context(self) -> UserContext:
        """Build current user context from memory."""
        facts = self._load_facts()
        recent_topics = self._extract_recent_topics()
        avg_vdi = (
            sum(self._vdi_samples) / len(self._vdi_samples)
            if self._vdi_samples else 0.5
        )
        dominant_mode = max(
            self._mode_counts,
            key=self._mode_counts.get,
            default="mixed"
        )
        session_count = self._count_sessions()
        last_summary  = self._get_last_summary()

        return UserContext(
            recent_topics        = recent_topics,
            emotional_pattern    = dominant_mode,
            avg_vdi              = round(avg_vdi, 3),
            session_count        = session_count,
            facts                = facts,
            last_session_summary = last_summary,
        )

    def distill_session(self) -> None:
        """
        Called on session end. Distills working memory into semantic facts
        and writes a session summary.
        """
        if not self._working:
            return

        avg_vdi = (
            sum(self._vdi_samples) / len(self._vdi_samples)
            if self._vdi_samples else 0.5
        )
        peak_mode = max(
            self._mode_counts,
            key=self._mode_counts.get,
            default="mixed"
        )

        # Build summary from high-importance user turns
        key_turns = [
            t.content[:100] for t in self._working
            if t.role == "user" and t.importance >= 0.7
        ][:5]
        summary = " | ".join(key_turns) if key_turns else "General conversation"

        self._update_session_log(avg_vdi, peak_mode, summary)
        self._extract_facts_from_session()

        logger.info(f"[Memory] Session {self.session_id} distilled")

    def get_pete_briefing(self) -> str:
        """
        Build a brief for Pete's system prompt — what she needs to know
        before the session starts. Compact. No fluff.
        """
        ctx = self.get_user_context()

        lines = []

        if ctx.session_count > 1:
            lines.append(f"[MEMORY — Session {ctx.session_count}]")
        else:
            lines.append("[MEMORY — First session]")

        if ctx.last_session_summary:
            lines.append(f"Last time: {ctx.last_session_summary[:200]}")

        if ctx.recent_topics:
            lines.append(f"Topics: {', '.join(ctx.recent_topics[:5])}")

        for fact in ctx.facts[:8]:
            if fact.category == "preference":
                lines.append(f"Preference: {fact.key} = {fact.value}")
            elif fact.category == "name":
                lines.append(f"Name: {fact.value}")
            elif fact.category == "project":
                lines.append(f"Working on: {fact.value}")

        if ctx.avg_vdi > 0.6:
            lines.append("Note: User tends toward emotional/intimate engagement.")
        elif ctx.avg_vdi < 0.35:
            lines.append("Note: User tends toward analytical/content-focused mode.")

        return "\n".join(lines) if lines else ""

    def upsert_fact(
        self,
        category:   str,
        key:        str,
        value:      str,
        confidence: float = 1.0,
    ) -> None:
        """Store or update a semantic fact."""
        with self._db() as conn:
            conn.execute("""
                INSERT INTO semantic_facts (category, key, value, confidence, last_seen, times_seen)
                VALUES (?, ?, ?, ?, ?, 1)
                ON CONFLICT(category, key) DO UPDATE SET
                    value      = excluded.value,
                    confidence = excluded.confidence,
                    last_seen  = excluded.last_seen,
                    times_seen = times_seen + 1
            """, (category, key, value, confidence, time.time()))

    # =========================================================================
    # DATABASE OPERATIONS
    # =========================================================================

    @contextmanager
    def _db(self):
        """Context manager for DB connections."""
        conn = sqlite3.connect(str(self.db_path), timeout=10.0)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"[Memory] DB error: {e}")
            raise
        finally:
            conn.close()

    def _init_db(self) -> None:
        with self._db() as conn:
            conn.executescript(SCHEMA)

    def _insert_turn(self, turn: MemoryTurn) -> None:
        with self._db() as conn:
            conn.execute("""
                INSERT INTO memory_turns
                    (session_id, role, content, vdi_score, voice_mode, importance, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                turn.session_id, turn.role, turn.content,
                turn.vdi_score, turn.voice_mode, turn.importance, turn.timestamp
            ))

    def _query_turns(
        self,
        query:          str,
        role_filter:    Optional[str],
        min_importance: float,
        limit:          int,
    ) -> List[MemoryTurn]:
        where_clauses = ["importance >= ?"]
        params: List[Any] = [min_importance]

        if role_filter:
            where_clauses.append("role = ?")
            params.append(role_filter)

        if query:
            where_clauses.append("content LIKE ?")
            params.append(f"%{query}%")

        where = " AND ".join(where_clauses)
        params.append(limit)

        with self._db() as conn:
            rows = conn.execute(f"""
                SELECT * FROM memory_turns
                WHERE {where}
                ORDER BY timestamp DESC
                LIMIT ?
            """, params).fetchall()

        return [
            MemoryTurn(
                role       = r["role"],
                content    = r["content"],
                vdi_score  = r["vdi_score"],
                voice_mode = r["voice_mode"],
                session_id = r["session_id"],
                timestamp  = r["timestamp"],
                importance = r["importance"],
            )
            for r in rows
        ]

    def _load_facts(self) -> List[SemanticFact]:
        with self._db() as conn:
            rows = conn.execute("""
                SELECT * FROM semantic_facts
                ORDER BY times_seen DESC, last_seen DESC
                LIMIT 20
            """).fetchall()
        return [
            SemanticFact(
                category   = r["category"],
                key        = r["key"],
                value      = r["value"],
                confidence = r["confidence"],
                last_seen  = r["last_seen"],
                times_seen = r["times_seen"],
            )
            for r in rows
        ]

    def _log_session_start(self) -> None:
        with self._db() as conn:
            conn.execute("""
                INSERT OR IGNORE INTO session_log (session_id, started_at)
                VALUES (?, ?)
            """, (self.session_id, self._session_start))

    def _update_session_log(
        self, avg_vdi: float, peak_mode: str, summary: str
    ) -> None:
        with self._db() as conn:
            conn.execute("""
                UPDATE session_log
                SET ended_at = ?, avg_vdi = ?, peak_mode = ?, summary = ?
                WHERE session_id = ?
            """, (time.time(), avg_vdi, peak_mode, summary, self.session_id))

    def _count_sessions(self) -> int:
        with self._db() as conn:
            row = conn.execute("SELECT COUNT(*) FROM session_log").fetchone()
        return row[0] if row else 1

    def _get_last_summary(self) -> str:
        with self._db() as conn:
            row = conn.execute("""
                SELECT summary FROM session_log
                WHERE session_id != ? AND summary IS NOT NULL
                ORDER BY ended_at DESC LIMIT 1
            """, (self.session_id,)).fetchone()
        return row["summary"] if row else ""

    def _extract_recent_topics(self) -> List[str]:
        """Extract topic keywords from recent user turns."""
        recent = [t.content for t in self._working if t.role == "user"][-10:]
        # Simple word frequency — no NLP dependency
        stop = {
            "the","a","an","is","it","to","and","or","but","in","on",
            "at","with","this","that","what","how","can","you","i","me",
            "my","we","do","did","have","has","for","not","are","be","was"
        }
        freq: Dict[str, int] = {}
        for text in recent:
            for word in text.lower().split():
                w = word.strip(".,!?\"'")
                if len(w) > 4 and w not in stop:
                    freq[w] = freq.get(w, 0) + 1
        sorted_words = sorted(freq, key=freq.get, reverse=True)
        return sorted_words[:8]

    def _extract_facts_inline(self, turn: MemoryTurn) -> None:
        """Fast inline fact extraction for high-importance turns."""
        content = turn.content

        # Name detection — only "my name is X" or "call me X" where X is capitalized
        name_match = re.search(r"(?:my name is|call me)\s+([A-Z][a-z]+)", content)
        if not name_match:
            name_match = re.search(r"I\'m\s+([A-Z][a-z]{2,})", content)
        if name_match:
            name_val = name_match.group(1).strip()
            not_names = {
                'The', 'An', 'A', 'In', 'On', 'At', 'Working', 'Building',
                'Going', 'Looking', 'Trying', 'Also', 'Not', 'Just', 'Very',
                'Here', 'There', 'Really', 'Sure', 'Sorry', 'Thanks',
            }
            if name_val not in not_names:
                self.upsert_fact("name", "user_name", name_val)

        # Project: explicit "project called X" only
        proj_match = re.search(
            r"(?:project called|my project is)\s+([A-Za-z0-9 ]+?)(?:\.|,|$)",
            content, re.I
        )
        if proj_match:
            val = proj_match.group(1).strip()[:50]
            if val:
                self.upsert_fact("project", "current_project", val)

        # System/tool: "building X" where X starts with capital
        tech_match = re.search(
            r"(?:building|working on)\s+([A-Z][A-Za-z0-9]+(?:\s+[A-Z][A-Za-z0-9]+)?)(?:\s|\.|,|$)",
            content
        )
        if tech_match:
            tech_val = tech_match.group(1).strip()
            if 3 < len(tech_val) < 60:
                self.upsert_fact("project", "building", tech_val)
    def _extract_facts_from_session(self) -> None:
        """End-of-session fact extraction from full working memory."""
        for turn in self._working:
            if turn.role == "user" and turn.importance >= 0.6:
                self._extract_facts_inline(turn)
