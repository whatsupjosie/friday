# 🎨 Frontend Integration Examples

Complete frontend code snippets for integrating camera vision into your UI.

---

## 📡 WebSocket Connection (Vanilla JavaScript)

### Basic WebSocket Client

```javascript
class CameraVisionClient {
    constructor(wsUrl = 'ws://localhost:8000/api/vision/stream') {
        this.wsUrl = wsUrl;
        this.ws = null;
        this.reconnectInterval = 2000;
        this.listeners = new Map();
    }
    
    connect() {
        this.ws = new WebSocket(this.wsUrl);
        
        this.ws.onopen = () => {
            console.log('✅ Connected to camera vision stream');
            this.emit('connected');
        };
        
        this.ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                this.handleMessage(data);
            } catch (error) {
                console.error('Failed to parse message:', error);
            }
        };
        
        this.ws.onclose = () => {
            console.log('❌ Disconnected from stream');
            this.emit('disconnected');
            // Auto-reconnect
            setTimeout(() => this.connect(), this.reconnectInterval);
        };
        
        this.ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            this.emit('error', error);
        };
    }
    
    handleMessage(data) {
        if (data.type === 'camera_frame') {
            this.emit('frame', data.data);
        } else if (data.type === 'camera_switched') {
            this.emit('camera_switched', data.camera_id);
        } else if (data.type === 'status') {
            this.emit('status', data.data);
        }
    }
    
    send(data) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify(data));
        }
    }
    
    switchCamera(cameraId) {
        this.send({
            type: 'switch_camera',
            camera_id: cameraId
        });
    }
    
    getStatus() {
        this.send({
            type: 'get_status'
        });
    }
    
    on(event, callback) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, []);
        }
        this.listeners.get(event).push(callback);
    }
    
    emit(event, data) {
        const callbacks = this.listeners.get(event) || [];
        callbacks.forEach(callback => callback(data));
    }
    
    disconnect() {
        if (this.ws) {
            this.ws.close();
        }
    }
}

// Usage
const visionClient = new CameraVisionClient();

visionClient.on('frame', (frame) => {
    console.log(`Frame ${frame.frame_id} from ${frame.camera_id}`);
    console.log(`Visible avatars: ${frame.visible_avatars.length}`);
    updateCameraDisplay(frame);
});

visionClient.on('connected', () => {
    console.log('Connected to camera stream!');
});

visionClient.connect();
```

---

## ⚛️ React Integration

### React Hook for Camera Vision

```jsx
import { useState, useEffect, useCallback, useRef } from 'react';

/**
 * Custom hook for camera vision integration
 */
export function useCameraVision(wsUrl = 'ws://localhost:8000/api/vision/stream') {
    const [connected, setConnected] = useState(false);
    const [cameras, setCameras] = useState({});
    const [primaryCamera, setPrimaryCamera] = useState(null);
    const wsRef = useRef(null);
    
    // Connect to WebSocket
    useEffect(() => {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;
        
        ws.onopen = () => {
            setConnected(true);
            console.log('✅ Camera vision connected');
        };
        
        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            
            if (data.type === 'camera_frame') {
                const frame = data.data;
                setCameras(prev => ({
                    ...prev,
                    [frame.camera_id]: frame
                }));
            } else if (data.type === 'camera_switched') {
                setPrimaryCamera(data.camera_id);
            }
        };
        
        ws.onclose = () => {
            setConnected(false);
            console.log('❌ Camera vision disconnected');
            // Reconnect after delay
            setTimeout(() => {
                // Trigger reconnect by changing state
            }, 2000);
        };
        
        return () => {
            ws.close();
        };
    }, [wsUrl]);
    
    // Switch camera
    const switchCamera = useCallback((cameraId) => {
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            wsRef.current.send(JSON.stringify({
                type: 'switch_camera',
                camera_id: cameraId
            }));
        }
    }, []);
    
    // Get status
    const getStatus = useCallback(() => {
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            wsRef.current.send(JSON.stringify({
                type: 'get_status'
            }));
        }
    }, []);
    
    return {
        connected,
        cameras,
        primaryCamera,
        switchCamera,
        getStatus
    };
}
```

### React Component Example

```jsx
import React from 'react';
import { useCameraVision } from './hooks/useCameraVision';

export function CameraVisionDashboard() {
    const { connected, cameras, primaryCamera, switchCamera } = useCameraVision();
    
    return (
        <div className="camera-dashboard">
            <div className="header">
                <h1>Camera Vision Dashboard</h1>
                <div className="status">
                    {connected ? (
                        <span className="status-connected">🟢 Connected</span>
                    ) : (
                        <span className="status-disconnected">🔴 Disconnected</span>
                    )}
                </div>
            </div>
            
            <div className="camera-grid">
                {Object.entries(cameras).map(([cameraId, frame]) => (
                    <CameraCard
                        key={cameraId}
                        cameraId={cameraId}
                        frame={frame}
                        isPrimary={cameraId === primaryCamera}
                        onSelect={() => switchCamera(cameraId)}
                    />
                ))}
            </div>
        </div>
    );
}

function CameraCard({ cameraId, frame, isPrimary, onSelect }) {
    const qualityColor = {
        good: '#4ade80',
        poor: '#fbbf24',
        blocked: '#f87171'
    }[frame.frame_quality];
    
    return (
        <div 
            className={`camera-card ${isPrimary ? 'primary' : ''}`}
            onClick={onSelect}
        >
            <div className="camera-header">
                <h3>{cameraId.toUpperCase()}</h3>
                <span 
                    className="quality-badge"
                    style={{ backgroundColor: qualityColor }}
                >
                    {frame.frame_quality}
                </span>
            </div>
            
            <div className="camera-info">
                <div className="info-row">
                    <span>Frame:</span>
                    <span>#{frame.frame_id}</span>
                </div>
                <div className="info-row">
                    <span>Exposure:</span>
                    <span>{frame.exposure_level.toFixed(2)}</span>
                </div>
                <div className="info-row">
                    <span>Avatars:</span>
                    <span>{frame.visible_avatars.length}</span>
                </div>
            </div>
            
            <div className="avatar-list">
                {frame.visible_avatars.map(avatar => (
                    <div key={avatar.object_id} className="avatar-item">
                        📍 {avatar.object_id} @ {avatar.distance.toFixed(1)}m
                    </div>
                ))}
            </div>
        </div>
    );
}
```

---

## 🎨 Vue.js Integration

### Vue 3 Composition API

```vue
<template>
  <div class="camera-vision">
    <div class="status">
      <span :class="connected ? 'connected' : 'disconnected'">
        {{ connected ? '🟢 Connected' : '🔴 Disconnected' }}
      </span>
    </div>
    
    <div class="cameras-grid">
      <div
        v-for="(frame, cameraId) in cameras"
        :key="cameraId"
        class="camera-card"
        @click="switchCamera(cameraId)"
      >
        <h3>{{ cameraId }}</h3>
        <div class="frame-info">
          <p>Frame: #{{ frame.frame_id }}</p>
          <p>Quality: <span :class="`quality-${frame.frame_quality}`">
            {{ frame.frame_quality }}
          </span></p>
          <p>Avatars: {{ frame.visible_avatars.length }}</p>
        </div>
        
        <div class="avatars">
          <div v-for="avatar in frame.visible_avatars" :key="avatar.object_id">
            {{ avatar.object_id }} @ {{ avatar.distance.toFixed(1) }}m
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';

const connected = ref(false);
const cameras = ref({});
let ws = null;

const connectWebSocket = () => {
  ws = new WebSocket('ws://localhost:8000/api/vision/stream');
  
  ws.onopen = () => {
    connected.value = true;
  };
  
  ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    
    if (data.type === 'camera_frame') {
      cameras.value[data.data.camera_id] = data.data;
    }
  };
  
  ws.onclose = () => {
    connected.value = false;
    setTimeout(connectWebSocket, 2000);
  };
};

const switchCamera = (cameraId) => {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({
      type: 'switch_camera',
      camera_id: cameraId
    }));
  }
};

onMounted(() => {
  connectWebSocket();
});

onUnmounted(() => {
  if (ws) {
    ws.close();
  }
});
</script>

<style scoped>
.camera-vision {
  padding: 20px;
}

.cameras-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
  margin-top: 20px;
}

.camera-card {
  background: #f3f4f6;
  border-radius: 8px;
  padding: 16px;
  cursor: pointer;
  transition: transform 0.2s;
}

.camera-card:hover {
  transform: translateY(-4px);
}

.quality-good { color: #10b981; }
.quality-poor { color: #f59e0b; }
.quality-blocked { color: #ef4444; }
</style>
```

---

## 📊 Data Visualization (Chart.js)

### Camera Stats Chart

```javascript
import Chart from 'chart.js/auto';

class CameraStatsChart {
    constructor(canvasId) {
        const ctx = document.getElementById(canvasId).getContext('2d');
        
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    {
                        label: 'Visible Avatars',
                        data: [],
                        borderColor: 'rgb(74, 222, 128)',
                        backgroundColor: 'rgba(74, 222, 128, 0.1)'
                    },
                    {
                        label: 'Exposure Level',
                        data: [],
                        borderColor: 'rgb(251, 191, 36)',
                        backgroundColor: 'rgba(251, 191, 36, 0.1)',
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Avatars Visible'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Exposure Level'
                        },
                        grid: {
                            drawOnChartArea: false
                        }
                    }
                }
            }
        });
    }
    
    update(frame) {
        const now = new Date().toLocaleTimeString();
        
        // Keep last 20 data points
        if (this.chart.data.labels.length > 20) {
            this.chart.data.labels.shift();
            this.chart.data.datasets[0].data.shift();
            this.chart.data.datasets[1].data.shift();
        }
        
        this.chart.data.labels.push(now);
        this.chart.data.datasets[0].data.push(frame.visible_avatars.length);
        this.chart.data.datasets[1].data.push(frame.exposure_level);
        
        this.chart.update('none'); // Update without animation for performance
    }
}

// Usage
const chart = new CameraStatsChart('cameraStatsChart');

visionClient.on('frame', (frame) => {
    chart.update(frame);
});
```

---

## 🗺️ 3D Scene Visualization (Three.js)

### Visualize Camera Positions and Views

```javascript
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';

class CameraVisionVisualizer {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.cameras = {};
        
        this.setupScene();
        this.setupRenderer();
        this.setupCamera();
        this.setupControls();
        this.setupLights();
        this.animate();
    }
    
    setupScene() {
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x1a1a2e);
        
        // Add grid
        const grid = new THREE.GridHelper(50, 50, 0x444444, 0x222222);
        this.scene.add(grid);
    }
    
    setupRenderer() {
        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
        this.container.appendChild(this.renderer.domElement);
    }
    
    setupCamera() {
        this.camera = new THREE.PerspectiveCamera(
            75,
            this.container.clientWidth / this.container.clientHeight,
            0.1,
            1000
        );
        this.camera.position.set(20, 20, 20);
        this.camera.lookAt(0, 0, 0);
    }
    
    setupControls() {
        this.controls = new OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = true;
    }
    
    setupLights() {
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        this.scene.add(ambientLight);
        
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
        directionalLight.position.set(10, 10, 5);
        this.scene.add(directionalLight);
    }
    
    updateCamera(frame) {
        const cameraId = frame.camera_id;
        
        // Remove old camera representation if exists
        if (this.cameras[cameraId]) {
            this.scene.remove(this.cameras[cameraId].group);
        }
        
        // Create camera group
        const group = new THREE.Group();
        
        // Camera body (cone pointing in direction)
        const geometry = new THREE.ConeGeometry(0.5, 1, 4);
        const material = new THREE.MeshPhongMaterial({ color: 0x4ade80 });
        const cone = new THREE.Mesh(geometry, material);
        cone.rotation.x = Math.PI / 2;
        group.add(cone);
        
        // Camera label
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        context.font = '48px Arial';
        context.fillStyle = 'white';
        context.fillText(cameraId, 0, 48);
        
        const texture = new THREE.CanvasTexture(canvas);
        const spriteMaterial = new THREE.SpriteMaterial({ map: texture });
        const sprite = new THREE.Sprite(spriteMaterial);
        sprite.position.y = 2;
        sprite.scale.set(2, 1, 1);
        group.add(sprite);
        
        // Position camera
        group.position.set(
            frame.camera_position.x,
            frame.camera_position.y,
            frame.camera_position.z
        );
        
        // Rotate based on camera rotation
        group.rotation.set(
            THREE.MathUtils.degToRad(frame.camera_rotation.x),
            THREE.MathUtils.degToRad(frame.camera_rotation.y),
            THREE.MathUtils.degToRad(frame.camera_rotation.z)
        );
        
        this.scene.add(group);
        this.cameras[cameraId] = { group, frame };
        
        // Add avatars
        this.updateAvatars(frame.visible_avatars);
    }
    
    updateAvatars(avatars) {
        avatars.forEach(avatar => {
            // Create avatar marker
            const geometry = new THREE.SphereGeometry(0.5, 16, 16);
            const material = new THREE.MeshPhongMaterial({ color: 0x3b82f6 });
            const sphere = new THREE.Mesh(geometry, material);
            
            sphere.position.set(
                avatar.position.x,
                avatar.position.y,
                avatar.position.z
            );
            
            this.scene.add(sphere);
        });
    }
    
    animate() {
        requestAnimationFrame(() => this.animate());
        
        this.controls.update();
        this.renderer.render(this.scene, this.camera);
    }
}

// Usage
const visualizer = new CameraVisionVisualizer('sceneVisualizer');

visionClient.on('frame', (frame) => {
    visualizer.updateCamera(frame);
});
```

---

## 📱 Mobile-Optimized (Touch Events)

```javascript
class MobileCameraVision {
    constructor() {
        this.touchStartX = 0;
        this.touchStartY = 0;
        this.currentCamera = 0;
        this.cameras = [];
        
        this.setupTouchHandlers();
    }
    
    setupTouchHandlers() {
        const container = document.getElementById('cameraContainer');
        
        container.addEventListener('touchstart', (e) => {
            this.touchStartX = e.touches[0].clientX;
            this.touchStartY = e.touches[0].clientY;
        });
        
        container.addEventListener('touchend', (e) => {
            const touchEndX = e.changedTouches[0].clientX;
            const touchEndY = e.changedTouches[0].clientY;
            
            const deltaX = touchEndX - this.touchStartX;
            const deltaY = touchEndY - this.touchStartY;
            
            // Swipe left/right to switch cameras
            if (Math.abs(deltaX) > 50 && Math.abs(deltaY) < 30) {
                if (deltaX > 0) {
                    this.previousCamera();
                } else {
                    this.nextCamera();
                }
            }
        });
    }
    
    nextCamera() {
        this.currentCamera = (this.currentCamera + 1) % this.cameras.length;
        this.switchCamera(this.cameras[this.currentCamera]);
    }
    
    previousCamera() {
        this.currentCamera = (this.currentCamera - 1 + this.cameras.length) % this.cameras.length;
        this.switchCamera(this.cameras[this.currentCamera]);
    }
    
    switchCamera(cameraId) {
        visionClient.switchCamera(cameraId);
        
        // Add haptic feedback
        if ('vibrate' in navigator) {
            navigator.vibrate(50);
        }
    }
}
```

---

## 🎯 Complete Example: Director View

```html
<!DOCTYPE html>
<html>
<head>
    <title>Camera Vision - Director View</title>
    <style>
        body {
            margin: 0;
            font-family: system-ui;
            background: #0f0f23;
            color: white;
        }
        
        .director-view {
            display: grid;
            grid-template-areas:
                "preview preview controls"
                "cam1 cam2 cam3";
            grid-template-columns: 1fr 1fr 400px;
            grid-template-rows: 2fr 1fr;
            height: 100vh;
            gap: 10px;
            padding: 10px;
        }
        
        .preview { grid-area: preview; }
        .cam1 { grid-area: cam1; }
        .cam2 { grid-area: cam2; }
        .cam3 { grid-area: cam3; }
        .controls { grid-area: controls; }
        
        .camera-view {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            padding: 15px;
            border: 2px solid transparent;
            transition: all 0.3s;
            cursor: pointer;
        }
        
        .camera-view:hover {
            border-color: rgba(74, 222, 128, 0.5);
        }
        
        .camera-view.active {
            border-color: #4ade80;
            box-shadow: 0 0 20px rgba(74, 222, 128, 0.3);
        }
        
        .preview {
            background: black;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2em;
        }
    </style>
</head>
<body>
    <div class="director-view">
        <div class="preview camera-view active">
            <div id="preview-content">PROGRAM</div>
        </div>
        
        <div class="cam1 camera-view" onclick="selectCamera('cam_wide')">
            <div id="cam1-content"></div>
        </div>
        
        <div class="cam2 camera-view" onclick="selectCamera('cam_medium')">
            <div id="cam2-content"></div>
        </div>
        
        <div class="cam3 camera-view" onclick="selectCamera('cam_closeup')">
            <div id="cam3-content"></div>
        </div>
        
        <div class="controls camera-view">
            <h2>Director Controls</h2>
            <button onclick="autoSelect()">Auto Select</button>
            <div id="stats"></div>
        </div>
    </div>
    
    <script src="camera-vision-client.js"></script>
    <script>
        const visionClient = new CameraVisionClient();
        let currentProgram = null;
        
        visionClient.on('frame', (frame) => {
            const container = document.getElementById(`${frame.camera_id}-content`);
            if (container) {
                container.innerHTML = `
                    <h3>${frame.camera_id}</h3>
                    <p>Quality: ${frame.frame_quality}</p>
                    <p>Avatars: ${frame.visible_avatars.length}</p>
                `;
            }
        });
        
        function selectCamera(cameraId) {
            visionClient.switchCamera(cameraId);
            currentProgram = cameraId;
            updateActiveStates();
        }
        
        function autoSelect() {
            fetch('/api/vision/broadcast/camera/auto', { method: 'POST' })
                .then(r => r.json())
                .then(data => {
                    currentProgram = data.selected_camera;
                    updateActiveStates();
                });
        }
        
        function updateActiveStates() {
            document.querySelectorAll('.camera-view').forEach(el => {
                el.classList.remove('active');
            });
            
            if (currentProgram) {
                const el = document.querySelector(`[onclick*="${currentProgram}"]`);
                if (el) el.classList.add('active');
            }
        }
        
        visionClient.connect();
    </script>
</body>
</html>
```

---

**All these examples are ready to use! Copy and customize for your needs! 🎨**
