"""
modules/llm_bridge.py — LLM Framework Bridge for E-Pete
=========================================================
Copyright (c) 2024-2025 Rear View Foresight LLC
"Feic Mo Chroí — See My Heart"

Adapts PubCast's llm_framework.py (Ollama/Groq/GGUF) to the
interface E-Pete expects: .generate(model, prompt, context) -> str

Usage:
    from modules.llm_bridge import LLMBridge
    from modules.llm_framework import LLMFramework  # existing PubCast module

    framework = LLMFramework(...)  # existing initialization
    bridge = LLMBridge(framework)
    evo = EVOOrchestrator(llm_backend=bridge, ...)
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class LLMBridge:
    """
    Adapter between PubCast's LLMFramework and E-Pete's expected interface.

    E-Pete calls:
        await backend.generate(model, prompt, context) -> str
        await backend.chat(model, messages) -> dict

    This bridge normalizes those calls to whatever PubCast's
    llm_framework.py actually provides.

    If llm_framework has no async support, this wraps sync calls
    in asyncio.to_thread() to avoid blocking the event loop.
    """

    def __init__(self, framework: Any):
        """
        Args:
            framework: Instance of PubCast's LLMFramework or compatible backend
        """
        self._fw = framework
        self._detect_interface()

    def _detect_interface(self) -> None:
        """Detect what methods the framework exposes."""
        self._has_generate    = hasattr(self._fw, 'generate')
        self._has_chat        = hasattr(self._fw, 'chat')
        self._has_complete    = hasattr(self._fw, 'complete')
        self._has_run         = hasattr(self._fw, 'run')
        self._has_invoke      = hasattr(self._fw, 'invoke')
        self._is_async_gen    = asyncio.iscoroutinefunction(
            getattr(self._fw, 'generate', None)
        )
        self._is_async_chat   = asyncio.iscoroutinefunction(
            getattr(self._fw, 'chat', None)
        )

        logger.info(
            f"[LLMBridge] Interface detected: "
            f"generate={self._has_generate}(async={self._is_async_gen}) "
            f"chat={self._has_chat}(async={self._is_async_chat}) "
            f"complete={self._has_complete} invoke={self._has_invoke}"
        )

    async def generate(
        self,
        model:   str,
        prompt:  str,
        context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate a completion. Normalizes to E-Pete's expected interface.
        Tries: generate → chat → complete → invoke → run
        """
        try:
            if self._has_generate:
                if self._is_async_gen:
                    return await self._fw.generate(model=model, prompt=prompt)
                else:
                    return await asyncio.to_thread(
                        self._fw.generate, model=model, prompt=prompt
                    )

            elif self._has_chat:
                result = await self.chat(
                    model=model,
                    messages=[{"role": "user", "content": prompt}]
                )
                return result.get("message", {}).get("content", "")

            elif self._has_complete:
                if asyncio.iscoroutinefunction(self._fw.complete):
                    return await self._fw.complete(prompt, model=model)
                else:
                    return await asyncio.to_thread(
                        self._fw.complete, prompt, model=model
                    )

            elif self._has_invoke:
                result = await asyncio.to_thread(
                    self._fw.invoke, prompt
                )
                return str(result)

            elif self._has_run:
                result = await asyncio.to_thread(
                    self._fw.run, prompt
                )
                return str(result)

            else:
                raise ValueError(
                    f"LLMBridge: framework has no supported method. "
                    f"Tried: generate, chat, complete, invoke, run"
                )

        except Exception as e:
            logger.error(f"[LLMBridge] generate failed: {e}")
            raise

    async def chat(
        self,
        model:    str,
        messages: List[Dict[str, str]],
    ) -> Dict[str, Any]:
        """
        Chat completion. Returns dict with 'message': {'content': str}.
        """
        try:
            if self._has_chat:
                if self._is_async_chat:
                    result = await self._fw.chat(
                        model=model, messages=messages
                    )
                else:
                    result = await asyncio.to_thread(
                        self._fw.chat, model=model, messages=messages
                    )

                # Normalize result format
                if isinstance(result, str):
                    return {"message": {"content": result}}
                elif isinstance(result, dict):
                    # Handle Ollama format: {"message": {"role": ..., "content": ...}}
                    if "message" in result:
                        return result
                    # Handle OpenAI format: {"choices": [{"message": {"content": ...}}]}
                    elif "choices" in result:
                        content = result["choices"][0]["message"]["content"]
                        return {"message": {"content": content}}
                    # Handle raw content dict
                    elif "content" in result:
                        return {"message": {"content": result["content"]}}
                    else:
                        return {"message": {"content": str(result)}}
                return {"message": {"content": str(result)}}

            elif self._has_generate:
                # Fall back to generate with last user message
                last_user = next(
                    (m["content"] for m in reversed(messages) if m["role"] == "user"),
                    ""
                )
                content = await self.generate(model=model, prompt=last_user)
                return {"message": {"content": content}}

            else:
                raise ValueError("LLMBridge: framework has no chat or generate method")

        except Exception as e:
            logger.error(f"[LLMBridge] chat failed: {e}")
            raise

    def get_available_models(self) -> List[str]:
        """Return list of available models if framework supports it."""
        if hasattr(self._fw, 'list_models'):
            try:
                return self._fw.list_models()
            except Exception:
                pass
        if hasattr(self._fw, 'models'):
            return list(self._fw.models.keys()) if isinstance(self._fw.models, dict) else self._fw.models
        return []
