"""
modules/event_bus.py — WebSocket Event Bus
===========================================
Copyright (c) 2024-2025 Rear View Foresight LLC
"Feic Mo Chroí — See My Heart"

The missing link between Pete's speech and the user's browser.

The alert path without this module was:
    E-Pete → Pete (queued in memory) → nowhere

The alert path with this module:
    E-Pete → Pete → EventBus → WebSocket → Browser

Also handles:
    - VDI state pushes (so UI can show voice mode indicator)
    - Priority vector pushes (so debug UI can show render state)
    - Pete speech pushes (so audio player gets SSML in real time)

Integration with hub.py / FastAPI:
    bus = PubCastEventBus()

    # Register a WebSocket client when they connect
    @app.websocket("/ws")
    async def ws_endpoint(websocket: WebSocket):
        client_id = await bus.connect(websocket)
        try:
            while True:
                data = await websocket.receive_text()
                # handle incoming...
        except WebSocketDisconnect:
            bus.disconnect(client_id)

    # Register Pete's speech handler
    evo.pete # (pete auto-registers alert handler with E-Pete)
    bus.register_pete_output_handler(evo.pete)
    # Now when Pete produces speech, it auto-pushes to all clients

Public API:
    PubCastEventBus
        .connect(websocket) -> str              # returns client_id
        .disconnect(client_id) -> None
        .push_pete_speech(text, ssml, params)   # Pete spoke — push to clients
        .push_vdi_state(vdi_report)             # VDI update — push to clients
        .push_system_status(status)             # E-Pete status — push to clients
        .push_priority_vector(vector)           # Switchblade decision — push
        .broadcast(event_type, payload) -> None # Generic push
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# EVENT TYPES
# ─────────────────────────────────────────────────────────────────────────────

class EventType:
    PETE_SPEECH     = "pete_speech"      # Pete produced speech
    PETE_ALERT      = "pete_alert"       # Pete is relaying a system alert
    VDI_STATE       = "vdi_state"        # VDI score/mode update
    SYSTEM_STATUS   = "system_status"   # E-Pete system status
    RENDER_VECTOR   = "render_vector"   # Switchblade priority vector
    ENGINE_STATE    = "engine_state"    # Distributed engine state change
    ERROR           = "error"           # Something went wrong


# ─────────────────────────────────────────────────────────────────────────────
# EVENT PAYLOAD
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BusEvent:
    event_type: str
    payload:    Dict[str, Any]
    timestamp:  float = field(default_factory=time.time)
    event_id:   str   = field(default_factory=lambda: str(uuid.uuid4())[:8])

    def to_json(self) -> str:
        return json.dumps({
            "type":      self.event_type,
            "payload":   self.payload,
            "ts":        self.timestamp,
            "id":        self.event_id,
        })


# ─────────────────────────────────────────────────────────────────────────────
# PUBCAST EVENT BUS
# ─────────────────────────────────────────────────────────────────────────────

class PubCastEventBus:
    """
    WebSocket event bus for PubCast AI.

    Manages connected browser clients and broadcasts events from
    the EVO stack (Pete speech, VDI state, system status, render vectors).

    Thread-safe via asyncio. All broadcast operations are coroutines.
    """

    def __init__(self):
        # Connected WebSocket clients: client_id -> websocket
        self._clients: Dict[str, Any] = {}  # Any = WebSocket
        self._client_lock = asyncio.Lock()

        # Event history for late-joining clients (last 20 events)
        self._history: List[BusEvent] = []
        self._history_limit = 20

        # Stats
        self._total_sent     = 0
        self._total_dropped  = 0  # Client disconnected before send

        logger.info("[EventBus] Initialized")

    # =========================================================================
    # CLIENT MANAGEMENT
    # =========================================================================

    async def connect(self, websocket: Any) -> str:
        """
        Register a new WebSocket client.
        Returns client_id for use in disconnect().
        Sends recent event history to the new client.
        """
        client_id = str(uuid.uuid4())[:8]
        async with self._client_lock:
            self._clients[client_id] = websocket

        logger.info(f"[EventBus] Client connected: {client_id} (total: {len(self._clients)})")

        # Send recent history so client has context
        for event in self._history[-5:]:
            try:
                await websocket.send_text(event.to_json())
            except Exception:
                pass  # Don't fail on history replay

        return client_id

    def disconnect(self, client_id: str) -> None:
        """Unregister a WebSocket client."""
        if client_id in self._clients:
            del self._clients[client_id]
            logger.info(f"[EventBus] Client disconnected: {client_id} (total: {len(self._clients)})")

    def client_count(self) -> int:
        """Return number of connected clients."""
        return len(self._clients)

    # =========================================================================
    # DOMAIN-SPECIFIC PUSH METHODS
    # =========================================================================

    async def push_pete_speech(
        self,
        text:       str,
        ssml:       str         = "",
        voice_mode: str         = "mixed",
        vdi_score:  float       = 0.5,
        elevenlabs: Optional[Dict] = None,
        is_alert:   bool        = False,
    ) -> None:
        """
        Pete produced speech — push text + synthesis params to all clients.
        Client uses this to:
            - Display Pete's text in the UI
            - Trigger TTS playback with correct voice settings
        """
        event = BusEvent(
            event_type = EventType.PETE_ALERT if is_alert else EventType.PETE_SPEECH,
            payload    = {
                "text":        text,
                "ssml":        ssml,
                "voice_mode":  voice_mode,
                "vdi_score":   round(vdi_score, 3),
                "elevenlabs":  elevenlabs or {},
                "is_alert":    is_alert,
            }
        )
        await self.broadcast_event(event)

    async def push_vdi_state(self, vdi_report: Any) -> None:
        """
        VDI update — push current emotional state to UI.
        Client uses this to show the voice mode indicator.
        """
        event = BusEvent(
            event_type = EventType.VDI_STATE,
            payload    = {
                "vdi_score":      round(vdi_report.vdi_score, 3),
                "voice_mode":     vdi_report.voice_mode.value,
                "identity":       vdi_report.identity_moment,
                "render":         round(vdi_report.render_intensity, 3),
                "silence_p":      round(vdi_report.silence_pressure, 3),
                "dominant":       vdi_report.dominant_signal,
            }
        )
        await self.broadcast_event(event)

    async def push_system_status(self, status: Any) -> None:
        """
        E-Pete system status — push to UI for monitoring panel.
        """
        event = BusEvent(
            event_type = EventType.SYSTEM_STATUS,
            payload    = {
                "engine_state":   status.engine_state,
                "render_load":    round(status.render_load, 1),
                "pending_tasks":  status.pending_tasks,
                "has_alert":      status.has_alert,
                "alert_level":    status.alert_level,
                "studio_ok":      status.studio_available,
                "architect_ok":   status.architect_available,
            }
        )
        await self.broadcast_event(event)

    async def push_priority_vector(self, vector: Any) -> None:
        """
        Switchblade priority vector — push to debug UI.
        Shows what render decisions were made this frame.
        """
        event = BusEvent(
            event_type = EventType.RENDER_VECTOR,
            payload    = vector.to_wire_format() if hasattr(vector, 'to_wire_format') else {}
        )
        await self.broadcast_event(event)

    async def push_engine_state(self, state: str, load: float) -> None:
        """Engine state change notification."""
        event = BusEvent(
            event_type = EventType.ENGINE_STATE,
            payload    = {"state": state, "load": round(load, 1)}
        )
        await self.broadcast_event(event)

    # =========================================================================
    # CORE BROADCAST
    # =========================================================================

    async def broadcast(self, event_type: str, payload: Dict[str, Any]) -> None:
        """Generic broadcast — creates and sends a BusEvent."""
        await self.broadcast_event(BusEvent(event_type=event_type, payload=payload))

    async def broadcast_event(self, event: BusEvent) -> None:
        """
        Broadcast a BusEvent to all connected clients.
        Always records in history regardless of client count —
        late-joining clients receive recent history on connect.
        """
        # Always record in history (even with no clients)
        self._history.append(event)
        if len(self._history) > self._history_limit:
            self._history.pop(0)

        if not self._clients:
            return

        message = event.to_json()
        if len(self._history) > self._history_limit:
            self._history.pop(0)

        # Collect dead clients
        dead_clients: Set[str] = set()

        async with self._client_lock:
            clients_snapshot = dict(self._clients)

        # Send outside lock to avoid holding it during I/O
        for client_id, ws in clients_snapshot.items():
            try:
                await ws.send_text(message)
                self._total_sent += 1
            except Exception as e:
                logger.debug(f"[EventBus] Client {client_id} send failed: {e}")
                dead_clients.add(client_id)
                self._total_dropped += 1

        # Clean up dead clients
        if dead_clients:
            async with self._client_lock:
                for cid in dead_clients:
                    self._clients.pop(cid, None)
            logger.info(f"[EventBus] Cleaned up {len(dead_clients)} dead client(s)")

    def get_stats(self) -> Dict[str, Any]:
        """Return event bus stats."""
        return {
            "connected_clients": len(self._clients),
            "total_sent":        self._total_sent,
            "total_dropped":     self._total_dropped,
            "history_depth":     len(self._history),
        }


# ─────────────────────────────────────────────────────────────────────────────
# EVO → EVENT BUS BRIDGE
# ─────────────────────────────────────────────────────────────────────────────

class EVOEventBridge:
    """
    Connects the EVOOrchestrator tick output to the EventBus.

    Call .attach(evo, bus) once after both are initialized.
    Then call .on_tick(tick) after every EVOOrchestrator.tick() call.

    This closes the loop:
        EVO.tick() → EVOEventBridge.on_tick() → EventBus → Browser
    """

    def __init__(self, bus: PubCastEventBus):
        self._bus = bus
        # Push VDI state every N ticks to avoid flooding (at 30fps, every 15 = 2Hz)
        self._vdi_push_interval = 15
        self._tick_count = 0

    async def on_tick(self, tick: Any) -> None:
        """
        Called after every EVOOrchestrator.tick().
        Pushes relevant state to connected browser clients.
        """
        self._tick_count += 1

        # VDI state — push at 2Hz (not every frame)
        if self._tick_count % self._vdi_push_interval == 0:
            if tick.vdi_report:
                await self._bus.push_vdi_state(tick.vdi_report)

        # Priority vector — push every frame (debug clients want this)
        if tick.priority_vector:
            await self._bus.push_priority_vector(tick.priority_vector)

    async def on_pete_speech(
        self,
        text:       str,
        ssml:       str,
        vdi_report: Any,
        elevenlabs: Optional[Dict] = None,
        is_alert:   bool = False,
    ) -> None:
        """
        Call this when Pete produces speech.
        Pushes text + synthesis params to all browser clients.
        """
        await self._bus.push_pete_speech(
            text       = text,
            ssml       = ssml,
            voice_mode = vdi_report.voice_mode.value if vdi_report else "mixed",
            vdi_score  = vdi_report.vdi_score if vdi_report else 0.5,
            elevenlabs = elevenlabs,
            is_alert   = is_alert,
        )

    async def on_system_status(self, status: Any) -> None:
        """Push E-Pete system status to browser clients."""
        await self._bus.push_system_status(status)
