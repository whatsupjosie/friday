"""
modules/recording_evo_bridge.py — Recording ↔ EVO Protocol Bridge
===================================================================
Copyright (c) 2024-2025 Rear View Foresight LLC
"Feic Mo Chroí — See My Heart"

Connects PubCast's RecordingService to the EVO Protocol.
When recording starts, EVO goes into maximum fidelity mode.
When recording stops, EVO returns to dynamic allocation.

Also bridges the Switchblade LOD decisions to the Avatar system.

Integration in main.py or hub.py:
    from modules.recording_evo_bridge import RecordingEVOBridge

    bridge = RecordingEVOBridge(evo_orchestrator, recording_service, avatar_system)
    # That's it — bridge registers callbacks automatically
"""
from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


# LOD → Avatar quality mapping
# Matches Switchblade LOD levels to avatar system quality settings
LOD_TO_AVATAR_QUALITY = {
    0: "identity",     # Full SSS, 4K textures, ray shadows
    1: "high",         # Good textures, baked shadows
    2: "medium",       # Compressed textures
    3: "low",          # Diffuse only
    4: "skeleton",     # Bones only — no mesh render
}


class RecordingEVOBridge:
    """
    Bridges RecordingService state to EVOOrchestrator.
    Bridges SwitchbladeGovernor LOD decisions to Avatar system.

    Automatically:
    - Locks EVO to maximum fidelity during recording
    - Unlocks EVO to dynamic allocation when recording stops
    - Translates Switchblade LOD levels to avatar quality settings
    """

    def __init__(
        self,
        evo:       Any,   # EVOOrchestrator
        recording: Any,   # RecordingService
        avatar:    Any,   # Avatar system (avatar.py)
    ):
        self._evo       = evo
        self._recording = recording
        self._avatar    = avatar
        self._recording_active = False

        # Register callbacks with RecordingService
        self._register_recording_callbacks()

        logger.info("[RecordingEVOBridge] Initialized")

    def _register_recording_callbacks(self) -> None:
        """Register with RecordingService for state change notifications."""
        if hasattr(self._recording, 'on_recording_start'):
            self._recording.on_recording_start(self._on_recording_start)
        if hasattr(self._recording, 'on_recording_stop'):
            self._recording.on_recording_stop(self._on_recording_stop)

        # Alternative: monkey-patch if no callback system
        if (not hasattr(self._recording, 'on_recording_start') and
                hasattr(self._recording, 'start')):
            original_start = self._recording.start
            original_stop  = self._recording.stop

            async def patched_start(*args, **kwargs):
                result = await original_start(*args, **kwargs)
                self._on_recording_start()
                return result

            async def patched_stop(*args, **kwargs):
                result = await original_stop(*args, **kwargs)
                self._on_recording_stop()
                return result

            self._recording.start = patched_start
            self._recording.stop  = patched_stop
            logger.info("[RecordingEVOBridge] Patched RecordingService.start/stop")

    def _on_recording_start(self) -> None:
        """
        Called when recording begins.
        Locks EVO to maximum fidelity — every frame matters.
        """
        self._recording_active = True
        logger.info("[RecordingEVOBridge] Recording started — EVO max fidelity mode")

        if not self._evo:
            return

        # Lock camera switching during recording
        if hasattr(self._evo, '_camera_manager') and self._evo._camera_manager:
            self._evo._camera_manager.auto_switching_enabled = False

        # Override Switchblade to force maximum render quality
        if hasattr(self._evo, 'switchblade'):
            self._evo.switchblade._recording_override = True

        # Override E-Pete to never defer during recording
        if hasattr(self._evo, 'epete'):
            self._evo.epete._recording_mode = True

    def _on_recording_stop(self) -> None:
        """
        Called when recording stops.
        Returns EVO to normal dynamic allocation.
        """
        self._recording_active = False
        logger.info("[RecordingEVOBridge] Recording stopped — EVO dynamic mode restored")

        if not self._evo:
            return

        # Re-enable auto-switching
        if hasattr(self._evo, '_camera_manager') and self._evo._camera_manager:
            self._evo._camera_manager.auto_switching_enabled = True

        # Remove recording override
        if hasattr(self._evo, 'switchblade'):
            self._evo.switchblade._recording_override = False

        if hasattr(self._evo, 'epete'):
            self._evo.epete._recording_mode = False

    def apply_lod_to_avatar(
        self,
        character_id: str,
        lod:          int,
    ) -> None:
        """
        Apply a Switchblade LOD level to the avatar system.
        Called by EVOOrchestrator after each Switchblade tick.
        """
        if not self._avatar:
            return

        quality = LOD_TO_AVATAR_QUALITY.get(lod, "medium")

        try:
            if hasattr(self._avatar, 'set_quality'):
                self._avatar.set_quality(character_id, quality)
            elif hasattr(self._avatar, 'set_lod'):
                self._avatar.set_lod(character_id, lod)
            elif hasattr(self._avatar, 'update_avatar'):
                self._avatar.update_avatar(character_id, {"quality": quality, "lod": lod})
        except Exception as e:
            logger.debug(f"[RecordingEVOBridge] Avatar LOD update failed: {e}")

    def apply_vector_to_avatars(self, vector: Any) -> None:
        """
        Apply a full Switchblade PriorityVector to all avatar characters.
        Call this after every EVOOrchestrator.tick().
        """
        if not self._avatar or not hasattr(vector, 'character_lod'):
            return

        for char_id, lod in vector.character_lod.items():
            self.apply_lod_to_avatar(char_id, lod)

    @property
    def is_recording(self) -> bool:
        """True if recording is currently active."""
        return self._recording_active
