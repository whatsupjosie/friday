
// EVO Protocol WebSocket Integration
// Add this to app.js after existing WebSocket setup

(function initEVOWebSocket() {
  const EVO_WS_URL = `ws://${window.location.host}/api/evo/ws`;
  let evoSocket = null;
  let reconnectTimer = null;

  function connectEVO() {
    evoSocket = new WebSocket(EVO_WS_URL);

    evoSocket.onmessage = function(event) {
      try {
        const msg = JSON.parse(event.data);
        handleEVOEvent(msg);
      } catch(e) {
        console.warn('[EVO] Failed to parse event:', e);
      }
    };

    evoSocket.onclose = function() {
      console.log('[EVO] WebSocket disconnected — reconnecting in 5s');
      reconnectTimer = setTimeout(connectEVO, 5000);
    };

    evoSocket.onerror = function(e) {
      console.warn('[EVO] WebSocket error:', e);
    };

    evoSocket.onopen = function() {
      console.log('[EVO] WebSocket connected');
      if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
    };
  }

  function handleEVOEvent(msg) {
    switch(msg.type) {
      case 'pete_speech':
        // Display Pete's text in the UI
        window.__pubcastEVOHook && window.__pubcastEVOHook('pete_speech', msg.payload);
        // Optionally trigger TTS with ElevenLabs settings
        if (msg.payload.elevenlabs && window.__pubcastTTSHook) {
          window.__pubcastTTSHook(msg.payload.text, msg.payload.elevenlabs);
        }
        break;

      case 'pete_alert':
        // System alert from E-Pete via Pete
        window.__pubcastEVOHook && window.__pubcastEVOHook('pete_alert', msg.payload);
        break;

      case 'vdi_state':
        // Update voice mode indicator
        const modeEl = document.getElementById('evo-voice-mode');
        if (modeEl) {
          modeEl.textContent = msg.payload.voice_mode;
          modeEl.className = `evo-mode-${msg.payload.voice_mode}`;
        }
        const vdiEl = document.getElementById('evo-vdi-score');
        if (vdiEl) vdiEl.textContent = (msg.payload.vdi_score * 100).toFixed(0) + '%';
        break;

      case 'system_status':
        // Update system health panel
        const stateEl = document.getElementById('evo-engine-state');
        if (stateEl) {
          stateEl.textContent = msg.payload.engine_state;
          stateEl.className = `evo-state-${msg.payload.engine_state}`;
        }
        break;

      case 'render_vector':
        // Debug only — log to console
        if (window.__pubcastDebugMode) {
          console.debug('[EVO] Render vector:', msg.payload);
        }
        break;

      case 'keepalive':
        break;
    }
  }

  // Start connection
  connectEVO();

  // Expose global hook for other scripts
  window.__pubcastEVOSocket = {
    send: (type, payload) => {
      if (evoSocket && evoSocket.readyState === WebSocket.OPEN) {
        evoSocket.send(JSON.stringify({ type, payload }));
      }
    },
    isConnected: () => evoSocket && evoSocket.readyState === WebSocket.OPEN,
  };
})();
