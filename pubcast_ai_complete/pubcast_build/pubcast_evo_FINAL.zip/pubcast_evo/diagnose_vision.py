#!/usr/bin/env python3
"""
PUBCAST CAMERA VISION - DIAGNOSTIC & TROUBLESHOOTING TOOL
Automatically detects and fixes common integration issues

Usage:
    python diagnose_vision.py
    python diagnose_vision.py --fix
    python diagnose_vision.py --verbose
"""

import sys
import os
import asyncio
import importlib
import json
from pathlib import Path
from typing import List, Dict, Any
import argparse

# ============================================================================
# DIAGNOSTIC TESTS
# ============================================================================

class DiagnosticResult:
    def __init__(self, name: str, passed: bool, message: str, fix_available: bool = False, fix_command: str = ""):
        self.name = name
        self.passed = passed
        self.message = message
        self.fix_available = fix_available
        self.fix_command = fix_command
    
    def __str__(self):
        icon = "✅" if self.passed else "❌"
        result = f"{icon} {self.name}: {self.message}"
        if not self.passed and self.fix_available:
            result += f"\n   💡 Fix: {self.fix_command}"
        return result


class VisionDiagnostics:
    def __init__(self, verbose=False):
        self.verbose = verbose
        self.results: List[DiagnosticResult] = []
        self.warnings: List[str] = []
    
    def log(self, message: str):
        if self.verbose:
            print(f"   {message}")
    
    async def run_all_tests(self):
        """Run all diagnostic tests"""
        print("\n" + "="*80)
        print("🔍 PUBCAST CAMERA VISION - DIAGNOSTIC TOOL")
        print("="*80 + "\n")
        
        tests = [
            ("Python Version", self.test_python_version),
            ("Dependencies", self.test_dependencies),
            ("Vision Files", self.test_vision_files),
            ("Import Test", self.test_imports),
            ("FastAPI Integration", self.test_fastapi_integration),
            ("Scene Format", self.test_scene_format),
            ("WebSocket Support", self.test_websocket),
            ("Port Availability", self.test_ports),
            ("Data Directories", self.test_directories),
            ("Memory Requirements", self.test_memory),
        ]
        
        for test_name, test_func in tests:
            print(f"\n🧪 Testing: {test_name}")
            try:
                result = await test_func()
                self.results.append(result)
                print(f"   {result}")
            except Exception as e:
                result = DiagnosticResult(
                    test_name,
                    False,
                    f"Test failed with error: {str(e)}",
                    False
                )
                self.results.append(result)
                print(f"   {result}")
        
        self.print_summary()
    
    async def test_python_version(self) -> DiagnosticResult:
        """Test Python version"""
        version = sys.version_info
        self.log(f"Python {version.major}.{version.minor}.{version.micro}")
        
        if version.major >= 3 and version.minor >= 8:
            return DiagnosticResult(
                "Python Version",
                True,
                f"Python {version.major}.{version.minor} (✓ 3.8+ required)"
            )
        else:
            return DiagnosticResult(
                "Python Version",
                False,
                f"Python {version.major}.{version.minor} (✗ 3.8+ required)",
                True,
                "Upgrade Python: https://python.org/downloads"
            )
    
    async def test_dependencies(self) -> DiagnosticResult:
        """Test required dependencies"""
        required = {
            'fastapi': 'FastAPI web framework',
            'uvicorn': 'ASGI server',
            'websockets': 'WebSocket support',
            'aiofiles': 'Async file operations'
        }
        
        missing = []
        for package, description in required.items():
            try:
                importlib.import_module(package)
                self.log(f"✓ {package} ({description})")
            except ImportError:
                missing.append(package)
                self.log(f"✗ {package} MISSING")
        
        if not missing:
            return DiagnosticResult(
                "Dependencies",
                True,
                "All required packages installed"
            )
        else:
            return DiagnosticResult(
                "Dependencies",
                False,
                f"Missing packages: {', '.join(missing)}",
                True,
                f"pip install {' '.join(missing)}"
            )
    
    async def test_vision_files(self) -> DiagnosticResult:
        """Test vision system files exist"""
        required_files = [
            'pubcast_vision_integration.py',
            'pubcast_vision_routes.py'
        ]
        
        missing = []
        for filename in required_files:
            if not Path(filename).exists():
                missing.append(filename)
                self.log(f"✗ {filename} NOT FOUND")
            else:
                self.log(f"✓ {filename}")
        
        if not missing:
            return DiagnosticResult(
                "Vision Files",
                True,
                "All vision system files present"
            )
        else:
            return DiagnosticResult(
                "Vision Files",
                False,
                f"Missing files: {', '.join(missing)}",
                True,
                "Copy vision files to project directory"
            )
    
    async def test_imports(self) -> DiagnosticResult:
        """Test vision system can be imported"""
        try:
            # Try to import vision system
            sys.path.insert(0, str(Path.cwd()))
            
            from pubcast_vision_integration import PubcastVisionManager
            from pubcast_vision_routes import create_vision_router
            
            self.log("✓ PubcastVisionManager imported")
            self.log("✓ create_vision_router imported")
            
            return DiagnosticResult(
                "Import Test",
                True,
                "Vision system modules import successfully"
            )
        except ImportError as e:
            return DiagnosticResult(
                "Import Test",
                False,
                f"Import failed: {str(e)}",
                True,
                "Check dependencies and file locations"
            )
        except Exception as e:
            return DiagnosticResult(
                "Import Test",
                False,
                f"Unexpected error: {str(e)}",
                False
            )
    
    async def test_fastapi_integration(self) -> DiagnosticResult:
        """Test FastAPI integration"""
        try:
            from fastapi import FastAPI
            app = FastAPI()
            
            # Try to create vision manager
            from pubcast_vision_integration import create_integrated_vision_manager
            vision_manager = create_integrated_vision_manager()
            
            # Try to integrate routes
            from pubcast_vision_routes import integrate_vision_with_fastapi
            integrate_vision_with_fastapi(app, vision_manager)
            
            self.log(f"✓ Created {len(app.routes)} routes")
            
            return DiagnosticResult(
                "FastAPI Integration",
                True,
                f"Successfully integrated with {len(app.routes)} routes"
            )
        except Exception as e:
            return DiagnosticResult(
                "FastAPI Integration",
                False,
                f"Integration failed: {str(e)}",
                False
            )
    
    async def test_scene_format(self) -> DiagnosticResult:
        """Test scene object format"""
        try:
            from pubcast_vision_integration import PubcastVisionManager
            
            manager = PubcastVisionManager()
            
            # Test scene format
            test_objects = [
                {"id": "test1", "type": "avatar", "x": 0, "y": 0, "z": 0}
            ]
            
            test_lights = [
                {"id": "light1", "x": 5, "y": 5, "z": -3, "intensity": 1.0}
            ]
            
            manager.update_scene_objects(test_objects, test_lights)
            
            self.log("✓ Scene format accepted")
            
            return DiagnosticResult(
                "Scene Format",
                True,
                "Scene object format validated"
            )
        except Exception as e:
            return DiagnosticResult(
                "Scene Format",
                False,
                f"Scene format error: {str(e)}",
                True,
                "Check INTEGRATION_GUIDE.md for correct format"
            )
    
    async def test_websocket(self) -> DiagnosticResult:
        """Test WebSocket support"""
        try:
            import websockets
            self.log("✓ websockets module available")
            
            # Check if we can create a WebSocket server
            async def handler(websocket, path):
                pass
            
            return DiagnosticResult(
                "WebSocket Support",
                True,
                "WebSocket functionality available"
            )
        except ImportError:
            return DiagnosticResult(
                "WebSocket Support",
                False,
                "websockets module not installed",
                True,
                "pip install websockets"
            )
        except Exception as e:
            return DiagnosticResult(
                "WebSocket Support",
                False,
                f"WebSocket test failed: {str(e)}",
                False
            )
    
    async def test_ports(self) -> DiagnosticResult:
        """Test if required ports are available"""
        import socket
        
        ports_to_test = [8000, 8888]
        in_use = []
        
        for port in ports_to_test:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            result = sock.connect_ex(('localhost', port))
            sock.close()
            
            if result == 0:
                in_use.append(port)
                self.log(f"✗ Port {port} in use")
            else:
                self.log(f"✓ Port {port} available")
        
        if not in_use:
            return DiagnosticResult(
                "Port Availability",
                True,
                "All required ports available"
            )
        else:
            return DiagnosticResult(
                "Port Availability",
                True,
                f"Ports in use: {in_use} (this is OK if server is running)",
                False
            )
    
    async def test_directories(self) -> DiagnosticResult:
        """Test data directories"""
        required_dirs = ['data', 'data/recordings']
        missing = []
        
        for dir_path in required_dirs:
            if not Path(dir_path).exists():
                missing.append(dir_path)
                self.log(f"✗ {dir_path} does not exist")
            else:
                self.log(f"✓ {dir_path} exists")
        
        if not missing:
            return DiagnosticResult(
                "Data Directories",
                True,
                "All required directories present"
            )
        else:
            return DiagnosticResult(
                "Data Directories",
                False,
                f"Missing directories: {', '.join(missing)}",
                True,
                f"mkdir -p {' '.join(missing)}"
            )
    
    async def test_memory(self) -> DiagnosticResult:
        """Test available memory"""
        try:
            import psutil
            mem = psutil.virtual_memory()
            available_gb = mem.available / (1024 ** 3)
            
            self.log(f"Available memory: {available_gb:.2f} GB")
            
            if available_gb >= 1.0:
                return DiagnosticResult(
                    "Memory Requirements",
                    True,
                    f"{available_gb:.2f} GB available (✓ 1GB+ recommended)"
                )
            else:
                return DiagnosticResult(
                    "Memory Requirements",
                    False,
                    f"Only {available_gb:.2f} GB available (1GB+ recommended)",
                    False
                )
        except ImportError:
            return DiagnosticResult(
                "Memory Requirements",
                True,
                "Could not check memory (psutil not installed)",
                False
            )
    
    def print_summary(self):
        """Print diagnostic summary"""
        print("\n" + "="*80)
        print("📊 DIAGNOSTIC SUMMARY")
        print("="*80 + "\n")
        
        passed = sum(1 for r in self.results if r.passed)
        total = len(self.results)
        
        print(f"Tests Passed: {passed}/{total}")
        
        failures = [r for r in self.results if not r.passed]
        if failures:
            print(f"\n❌ Failed Tests ({len(failures)}):")
            for result in failures:
                print(f"\n{result}")
        
        fixable = [r for r in failures if r.fix_available]
        if fixable:
            print(f"\n💡 Quick Fixes Available:")
            for result in fixable:
                print(f"   • {result.name}: {result.fix_command}")
        
        if passed == total:
            print("\n✅ All tests passed! Your vision system is ready!")
            print("\nNext steps:")
            print("  1. Run: python instant_test_server.py")
            print("  2. Visit: http://localhost:8888/demo")
            print("  3. Integrate with your main.py (see INTEGRATION_GUIDE.md)")
        else:
            print(f"\n⚠️  {len(failures)} issue(s) found. Fix these before deployment.")
        
        print("\n" + "="*80 + "\n")


# ============================================================================
# AUTO-FIX FUNCTIONALITY
# ============================================================================

class AutoFixer:
    def __init__(self, diagnostics: VisionDiagnostics):
        self.diagnostics = diagnostics
    
    async def auto_fix(self):
        """Automatically fix common issues"""
        print("\n" + "="*80)
        print("🔧 AUTO-FIX MODE")
        print("="*80 + "\n")
        
        fixable = [r for r in self.diagnostics.results if not r.passed and r.fix_available]
        
        if not fixable:
            print("✅ No auto-fixable issues found!")
            return
        
        print(f"Found {len(fixable)} fixable issues:\n")
        
        for result in fixable:
            print(f"🔧 Fixing: {result.name}")
            print(f"   Command: {result.fix_command}")
            
            if "pip install" in result.fix_command:
                await self.fix_pip_install(result.fix_command)
            elif "mkdir" in result.fix_command:
                await self.fix_mkdir(result.fix_command)
            else:
                print(f"   ℹ️  Manual fix required: {result.fix_command}")
            
            print()
    
    async def fix_pip_install(self, command: str):
        """Fix pip installation issues"""
        try:
            import subprocess
            # Extract package names
            packages = command.replace("pip install", "").strip().split()
            
            print(f"   Installing: {', '.join(packages)}")
            result = subprocess.run(
                ['pip', 'install'] + packages,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                print("   ✅ Installation successful")
            else:
                print(f"   ❌ Installation failed: {result.stderr}")
        except Exception as e:
            print(f"   ❌ Error: {e}")
    
    async def fix_mkdir(self, command: str):
        """Fix directory issues"""
        try:
            # Extract directory paths
            dirs = command.replace("mkdir -p", "").strip().split()
            
            for dir_path in dirs:
                Path(dir_path).mkdir(parents=True, exist_ok=True)
                print(f"   ✅ Created: {dir_path}")
        except Exception as e:
            print(f"   ❌ Error: {e}")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

async def main():
    parser = argparse.ArgumentParser(description='PubCast Camera Vision Diagnostic Tool')
    parser.add_argument('--fix', action='store_true', help='Automatically fix issues')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    parser.add_argument('--json', action='store_true', help='Output as JSON')
    
    args = parser.parse_args()
    
    diagnostics = VisionDiagnostics(verbose=args.verbose)
    await diagnostics.run_all_tests()
    
    if args.fix:
        fixer = AutoFixer(diagnostics)
        await fixer.auto_fix()
        
        # Re-run tests
        print("\n🔄 Re-running diagnostics...\n")
        diagnostics = VisionDiagnostics(verbose=args.verbose)
        await diagnostics.run_all_tests()
    
    if args.json:
        results = {
            "passed": sum(1 for r in diagnostics.results if r.passed),
            "total": len(diagnostics.results),
            "tests": [
                {
                    "name": r.name,
                    "passed": r.passed,
                    "message": r.message
                }
                for r in diagnostics.results
            ]
        }
        print("\n" + json.dumps(results, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
