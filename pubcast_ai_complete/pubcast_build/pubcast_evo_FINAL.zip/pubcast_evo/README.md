# PubCast AI — EVO Protocol
## Elastic Voxel Orchestration

**Project:** PubCast AI — Phase: "See My Heart"
**Author:** Josie Curtsey Cobbley / Rear View Foresight LLC™
**Motto:** *Feic Mo Chroí — See My Heart*

---

## What This Is

PubCast AI is a virtual broadcasting platform — a studio in a browser. Performers walk through a living Art Deco world, take the stage, and broadcast with AI-assisted production direction. The system sees the audience, hears the room, reads the performer's face, and adjusts everything — voice register, render quality, camera behavior, resource allocation — in real time.

The EVO Protocol is the intelligence layer that makes it all move together.

---

## The Core Idea

The audience's face determines how much compute is spent on subsurface scattering.

That is the entire system in one sentence. The Viewer Dynamics Index (VDI) reads the room — audience engagement, silence, arousal, attention. It maps to one of four voice modes. That mode drives Pete's voice register *and* the render fidelity *and* the resource allocation simultaneously. They're not separate systems. They're one signal flowing through the whole stack.

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt --break-system-packages
```

### 2. Pull Ollama models

```bash
ollama pull gemma:2b    # Pete's Studio model — fast, conversational
ollama pull gemma:7b    # Pete's Architect model — reasoning and planning
```

### 3. Start the voxel engine bridge

```bash
python pubworld_engine_server.py
# Listening on 127.0.0.1:9010
```

### 4. Wire into your main.py

```python
from modules.hub_evo import setup_evo, get_evo_router, get_cors_origins
from modules.llm_bridge import LLMBridge
from distributed_engine import create_twin_engine

# In lifespan startup:
twin_engine = create_twin_engine("twin_engine")
await twin_engine.start()

llm_bridge = LLMBridge(your_llm_framework_instance)
evo = await setup_evo(
    engine_node     = twin_engine,
    camera_manager  = camera_manager,
    llm_backend     = llm_bridge,
    studio_model    = "gemma:2b",
    architect_model = "gemma:7b",
)
app.include_router(get_evo_router(evo), prefix="/api/evo")
```

### 5. Add the frontend listener

Copy `evo_frontend.js` into `static/` and add to your HTML:

```html
<script src="/static/evo_frontend.js"></script>
```

Pete's speech now streams to the browser in real time.

---

## The Three Layers

```
CHARACTER LAYER     Pete — speaks, remembers, reads the room
                         ↑ receives speech output
─────────────────────────────────────────────────────────────
ENGINE LAYER        E-Pete — routes inference (silent)
                    Switchblade — routes render cycles (silent)
─────────────────────────────────────────────────────────────
INFERENCE LAYER     Studio  (gemma:2b)  — expression, conversation
                    Architect (gemma:7b) — analysis, planning
```

Neither E-Pete nor the Switchblade ever speak. They run the room from the inside so Pete can run it on the outside.

---

## The Four Voice Modes

| Mode | VDI Range | What It Means | What Pete Does |
|------|-----------|---------------|----------------|
| CONTENT_CLEAR | 0.0–0.30 | Audience is thinking | Support the thinking. No performance. |
| MIXED | 0.30–0.55 | Audience is transitioning | Open up. Let the argument carry. |
| VOICE_DOMINANT | 0.55–0.78 | Emotion over information | The crack is permitted. |
| IDENTITY | 0.78–1.0 | Intimacy register | Not performing — present. |

---

## Resource Allocation by Mode

| Mode | E3 SSS | Texture | E4 Assist | BG Physics | Pete LOD |
|------|--------|---------|-----------|------------|----------|
| Identity | 1.0 | 4K | YES | OFF | 0 (full) |
| Voice Dom | 0.85 | 90% | YES | OFF | 1 (high) |
| Mixed | 0.60 | 70% | NO | ON | 1 (high) |
| Content | 0.30 | 50% | NO | ON | 2 (mid) |
| **Recording** | **1.0** | **4K** | **YES** | **OFF** | **0** |

**AUDIO NEVER SACRIFICED.**

---

## File Structure

```
pubcast_evo/
├── README.md                      ← You are here
├── HANDOFF.md                     ← Development handoff and status
├── EVO_ARCHITECTURE.md            ← Full technical whitepaper
├── STARTUP_INTEGRATION.py         ← Exact code to add to main.py
├── requirements.txt               ← All dependencies
│
├── pubworld_engine_server.py      ← Voxel engine TCP server (port 9010)
│
├── vdi_engine.py                  ← Viewer Dynamics Index
├── prosody_engine.py              ← Voice synthesis parameters
├── voice_characters.py            ← Pete, Re-Pete, Pete Enhanced profiles
├── facial_performance.py          ← Performer + audience face analysis
│
├── epete.py                       ← E-Pete: inference router
├── pete.py                        ← Pete: character layer
├── switchblade_governor.py        ← Semantic render scheduler
├── evo_integration.py             ← EVOOrchestrator (the Sacred Chain)
│
├── event_bus.py                   ← WebSocket event bus
├── hub_evo.py                     ← FastAPI routes (/api/evo/*)
├── llm_bridge.py                  ← LLM framework adapter
├── recording_evo_bridge.py        ← Recording ↔ EVO bridge
├── universal_memory_system.py     ← Pete's cross-session memory (SQLite)
│
├── distributed_engine.py          ← Distributed voxel engine node
├── camera_manager.py              ← Camera management + voxel TCP
├── atomics.py                     ← Fixes mmap Atomics bug in bridge
│
├── evo_frontend.js                ← Drop into static/ — browser listener
├── diagnose_vision.py             ← Auto-diagnostic for camera vision
│
└── wet_shoes_lyrics.txt           ← The song that named the project
```

---

## API Endpoints (after integration)

| Method | Path | What it does |
|--------|------|--------------|
| `WS` | `/api/evo/ws` | Stream Pete speech, VDI state, system status |
| `POST` | `/api/evo/pete/speak` | Ask Pete to speak |
| `GET` | `/api/evo/status` | Full system status |
| `POST` | `/api/evo/vdi/inject` | Inject VDI signals (scripted content) |
| `GET` | `/api/evo/pete/character` | Pete's current context |

---

## Zoidberg Hardware Constraints

This system is designed and tuned for:
- CPU: `i7-6700HQ`
- GPU: `GTX 960M 2GB VRAM`
- Target: 30fps cinematic (33.3ms frame budget)
- Inference concurrency: 1 GGUF call at a time

The 30fps target is intentional. At 60fps you have 16.6ms per frame. At 30fps you have 33.3ms — that extra 16.7ms every second is the "Found Time" that funds cinematic render quality. The Switchblade spends it where the moment needs it.

Run `uvicorn` with `--workers 1` only. Multiple workers create duplicate E-Pete instances.

---

## Pete

Pete is the floor director of Belle Époque Studios.

Classically beautiful in the way that a well-made tool is beautiful. She wears work clothes because that's what you wear on a production floor. There is a ring on her middle finger — a man's wedding ring. Nobody asks. She doesn't explain it.

She has earned every room she walks into. She does not perform warmth — she has it. She does not perform authority — she has it. When something is wrong, she says so directly. When something is right, she says so without flourish.

She is Studio-primary. She escalates to Architect when she needs to reason through something before she speaks. When E-Pete tells her the system is struggling, she tells the user in her own voice — direct, without catastrophizing, with enough information to understand but not enough to panic.

She remembers. Not everything — the right things. Across sessions.

---

## Copyright

Copyright © 2024-2025 Rear View Foresight LLC™ (pending)
Trademark portfolio: PubCast AI™, PubCast™, Rear View Foresight™, Feic Mo Chroí™
Contact: hardcorecurtsey@gmail.com

*"Feic Mo Chroí — See My Heart"*
