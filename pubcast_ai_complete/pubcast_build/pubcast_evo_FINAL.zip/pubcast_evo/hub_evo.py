"""
modules/hub_evo.py — EVO Protocol Hub Integration
===================================================
Copyright (c) 2024-2025 Rear View Foresight LLC
"Feic Mo Chroí — See My Heart"

Wires the EVO Protocol (E-Pete, Pete, VDI, Switchblade) into PubCast's
FastAPI hub. Drop this into modules/ and import it in main.py.

Usage in main.py:
    from modules.hub_evo import setup_evo, get_evo_router

    # After creating FastAPI app:
    evo = await setup_evo(engine_node, camera_manager, llm_backend)
    app.include_router(get_evo_router(evo), prefix="/api/evo")

WebSocket clients connect to /ws/evo to receive:
    - Pete speech events (pete_speech)
    - VDI state updates (vdi_state)
    - System status (system_status)
    - Render vector (render_vector)
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from typing import Any, Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# EVO imports — try package, fallback to direct
try:
    from pubcast_evo.evo_integration import EVOOrchestrator, EVOTick
    from pubcast_evo.event_bus import PubCastEventBus, EVOEventBridge
    from pubcast_evo.switchblade_governor import SceneState
    from pubcast_evo.vdi_engine import VDISignals
except ImportError:
    import sys
    sys.path.insert(0, "..")
    from evo_integration import EVOOrchestrator, EVOTick
    from event_bus import PubCastEventBus, EVOEventBridge
    from switchblade_governor import SceneState
    from vdi_engine import VDISignals

logger = logging.getLogger(__name__)

# ── Singletons ────────────────────────────────────────────────────────────────
_evo: Optional[EVOOrchestrator] = None
_bus: Optional[PubCastEventBus] = None
_bridge: Optional[EVOEventBridge] = None


def get_cors_origins(env: str = "development") -> list:
    """
    Return appropriate CORS origins for the environment.
    NEVER use ['*'] in production — locks down to known origins.

    Usage in main.py:
        from modules.hub_evo import get_cors_origins
        app.add_middleware(CORSMiddleware,
            allow_origins=get_cors_origins(os.getenv("ENV", "development")),
            allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
    """
    if env == "production":
        return [
            "http://localhost:8000",
            "http://127.0.0.1:8000",
            # Add your actual production domain here
        ]
    # Development: restrict to localhost variants only (not wildcard)
    return [
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "http://localhost:3000",   # Dev frontend
        "http://localhost:5173",   # Vite dev server
    ]


_evo_initialized = False   # Guard against accidental double-init


async def setup_evo(
    engine_node:    Any,
    camera_manager: Any,
    llm_backend:    Any = None,
    studio_model:   str = "gemma:2b",
    architect_model: str = "gemma:7b",
) -> EVOOrchestrator:
    """
    Initialize EVO Protocol and wire it into PubCast.
    Call this ONCE during app startup (lifespan handler).
    Idempotent — safe to call multiple times but only initializes once.

    Args:
        engine_node:    DistributedEngineNode instance
        camera_manager: AdvancedCameraManager instance
        llm_backend:    LLM framework instance (from llm_framework.py)
        studio_model:   Ollama model name for Studio (small/fast Gemma)
        architect_model: Ollama model name for Architect (larger Gemma)
    
    IMPORTANT: Run uvicorn with workers=1 only.
        uvicorn main:app --workers 1
    Multiple workers create duplicate E-Pete instances with separate
    inference semaphores — inference will be split incorrectly.
    """
    global _evo, _bus, _bridge, _evo_initialized

    if _evo_initialized and _evo is not None:
        logger.warning("[EVO Hub] setup_evo() called again — returning existing instance")
        return _evo

    logger.info("[EVO Hub] Setting up EVO Protocol...")

    _evo = EVOOrchestrator(
        active_character   = "pete",
        llm_backend        = llm_backend,
        studio_model_id    = studio_model,
        architect_model_id = architect_model,
    )

    _bus    = PubCastEventBus()
    _bridge = EVOEventBridge(bus=_bus)

    await _evo.start(engine_node, camera_manager)

    _evo_initialized = True
    logger.info("[EVO Hub] EVO Protocol online — Pete ready, E-Pete routing")
    return _evo


def get_evo() -> Optional[EVOOrchestrator]:
    """Get EVO orchestrator singleton."""
    return _evo


def get_bus() -> Optional[PubCastEventBus]:
    """Get EventBus singleton."""
    return _bus


# ── Request Models ────────────────────────────────────────────────────────────

class PeteSpeakRequest(BaseModel):
    text:           str
    vdi_score:      float = 0.5
    character:      str   = "pete"
    push_to_ws:     bool  = True    # Push result to WebSocket clients


class VDISignalUpdate(BaseModel):
    """Manual VDI signal injection (for testing or scripted sequences)."""
    audience_engagement:    float = 0.5
    audience_silence:       float = 0.5
    audience_arousal:       float = 0.5
    topic_emotional_weight: float = 0.5


# ── Router ────────────────────────────────────────────────────────────────────

def get_evo_router(evo: EVOOrchestrator) -> APIRouter:
    """Build the EVO API router. Include in app with app.include_router(...)."""
    router = APIRouter(tags=["EVO Protocol"])

    @router.websocket("/ws")
    async def evo_websocket(websocket: WebSocket):
        """
        EVO WebSocket endpoint.
        Clients connect here to receive Pete speech, VDI state,
        system status, and render vector events in real time.
        """
        await websocket.accept()
        if _bus is None:
            await websocket.send_json({"error": "EVO not initialized"})
            await websocket.close()
            return

        client_id = await _bus.connect(websocket)
        logger.info(f"[EVO WS] Client connected: {client_id}")

        try:
            while True:
                # Keep connection alive — client can send pings
                try:
                    data = await asyncio.wait_for(
                        websocket.receive_text(), timeout=30.0
                    )
                    # Handle client commands (future: scene state updates)
                    if data == "ping":
                        await websocket.send_text("pong")
                except asyncio.TimeoutError:
                    # Send keepalive
                    await websocket.send_json({"type": "keepalive"})
        except WebSocketDisconnect:
            pass
        finally:
            _bus.disconnect(client_id)
            logger.info(f"[EVO WS] Client disconnected: {client_id}")

    @router.post("/pete/speak")
    async def pete_speak(req: PeteSpeakRequest):
        """
        Ask Pete to speak.
        Routes through E-Pete inference, returns text + SSML + synthesis params.
        Optionally pushes result to all WebSocket clients.
        """
        if evo is None:
            return JSONResponse({"error": "EVO not initialized"}, status_code=503)

        # Get current VDI state from EVO
        state = evo.get_current_state()

        # Inject manual VDI score if provided
        from vdi_engine import VDIEngine, VDISignals as VS
        sig = VS(
            audience_engagement=req.vdi_score,
            audience_arousal=req.vdi_score,
            topic_emotional_weight=req.vdi_score,
            audience_silence=req.vdi_score if req.vdi_score > 0.7 else 0.3,
        )
        vdi_report = evo.vdi_engine.update(sig)

        result = await evo.pete.speak_with_ssml(
            user_input = req.text,
            vdi_report = vdi_report,
        )

        # Push to WebSocket clients if requested
        if req.push_to_ws and _bridge and _bus:
            await _bridge.on_pete_speech(
                text       = result["text"],
                ssml       = result.get("ssml", ""),
                vdi_report = vdi_report,
                elevenlabs = result.get("elevenlabs"),
            )

        return JSONResponse({
            "text":        result["text"],
            "ssml":        result.get("ssml", ""),
            "voice_mode":  result.get("voice_mode", "mixed"),
            "vdi_score":   round(vdi_report.vdi_score, 3),
            "elevenlabs":  result.get("elevenlabs", {}),
        })

    @router.get("/status")
    async def evo_status():
        """Get complete EVO system status."""
        if evo is None:
            return JSONResponse({"error": "EVO not initialized"}, status_code=503)

        state     = evo.get_current_state()
        ep_metrics = evo.epete.get_metrics()
        ep_status  = evo.epete.get_system_status()
        bus_stats  = _bus.get_stats() if _bus else {}

        return JSONResponse({
            "evo":     state,
            "epete":   ep_metrics,
            "system":  {
                "engine_state":  ep_status.engine_state,
                "render_load":   ep_status.render_load,
                "pending_tasks": ep_status.pending_tasks,
                "alert_level":   ep_status.alert_level,
            },
            "bus":     bus_stats,
        })

    @router.post("/vdi/inject")
    async def inject_vdi(req: VDISignalUpdate):
        """Manually inject VDI signals (for testing/scripted content)."""
        if evo is None:
            return JSONResponse({"error": "EVO not initialized"}, status_code=503)

        from vdi_engine import VDISignals as VS
        signals = VS(
            audience_engagement    = req.audience_engagement,
            audience_silence       = req.audience_silence,
            audience_arousal       = req.audience_arousal,
            topic_emotional_weight = req.topic_emotional_weight,
        )
        report = evo.inject_signals(signals)

        # Push VDI state update to WebSocket clients
        if _bridge and _bus:
            await _bus.push_vdi_state(report)

        return JSONResponse({
            "vdi_score":  round(report.vdi_score, 3),
            "voice_mode": report.voice_mode.value,
            "identity":   report.identity_moment,
        })

    @router.get("/pete/character")
    async def pete_character_info():
        """Get Pete's current character context."""
        if evo is None:
            return JSONResponse({"error": "EVO not initialized"}, status_code=503)
        return JSONResponse(evo.pete.get_character_context())

    return router
