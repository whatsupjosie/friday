"""
CHOREOGRAPHY RUNTIME - Production Edition
==========================================
Avatar animation orchestration system with cinematic easing, 
state management, and frame recording capabilities.

Fixes Applied:
- Performance: O(1) avatar lookup with caching (was O(n²))
- Logical: Serialization state leakage prevention
- Syntax: Removed stray JSON brace
- Optimization: Completed step skipping
- Optimization: Circular buffer frame recording
- Optimization: Avatar cache lifecycle management
"""

from __future__ import annotations
import json
import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional


class Easing:
    """Common easing helpers for cinematic motion."""
    
    @staticmethod
    def ease_in_out_cubic(t: float) -> float:
        """Smooth cubic interpolation for natural-feeling motion."""
        return 4 * t * t * t if t < 0.5 else 1 - pow(-2 * t + 2, 3) / 2
    
    @staticmethod
    def ease_in_quad(t: float) -> float:
        """Acceleration from zero velocity."""
        return t * t
    
    @staticmethod
    def ease_out_quad(t: float) -> float:
        """Deceleration to zero velocity."""
        return 1 - (1 - t) ** 2
    
    @staticmethod
    def ease_in_out_sine(t: float) -> float:
        """Smooth sinusoidal interpolation."""
        return -(math.cos(math.pi * t) - 1) / 2


@dataclass
class ChoreographyStep:
    """
    Single animation step within a choreography sequence.
    
    Captures initial state on activation and interpolates to target over duration.
    Tracks completion to skip unnecessary computation.
    """
    avatar_id: str
    animation_type: str
    start_time: float
    duration: float
    target_position: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    target_rotation: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    target_skeleton: Dict[str, List[float]] = field(default_factory=dict)
    
    # Runtime state (not serialized)
    initial_position: List[float] = field(default_factory=list, init=False, repr=False)
    initial_rotation: List[float] = field(default_factory=list, init=False, repr=False)
    initial_skeleton: Dict[str, List[float]] = field(default_factory=dict, init=False, repr=False)
    completed: bool = field(default=False, init=False, repr=False)

    def activate(self, avatar) -> None:
        """Capture the avatar state when the step becomes active."""
        self.initial_position = list(getattr(avatar, "position", [0.0, 0.0, 0.0]))
        self.initial_rotation = list(getattr(avatar, "rotation", [0.0, 0.0, 0.0]))
        getter = getattr(avatar, "get_full_skeleton_data", None)
        self.initial_skeleton = getter() if callable(getter) else {}
        self.completed = False

    def update(self, avatar, current_time: float) -> None:
        """
        Update avatar animation state for the current time.
        Skips processing if already completed.
        """
        # --- OPTIMIZATION FIX ---
        # Skip already-completed steps to avoid redundant computation
        if self.completed or not self.is_active(current_time):
            return

        progress = (current_time - self.start_time) / max(self.duration, 0.001)
        eased = Easing.ease_in_out_cubic(max(0.0, min(1.0, progress)))

        if self.animation_type in {"walk", "move"}:
            # Smooth position interpolation
            for idx in range(3):
                delta = self.target_position[idx] - self.initial_position[idx]
                avatar.position[idx] = self.initial_position[idx] + delta * eased

        elif self.animation_type == "turn":
            # Rotation around Y-axis (yaw)
            delta = self.target_rotation[1] - self.initial_rotation[1]
            avatar.rotation[1] = self.initial_rotation[1] + delta * eased

        elif self.animation_type == "pose_transition" and self.target_skeleton:
            # Skeletal animation blending
            apply_pose = getattr(avatar, "apply_pose_data", None)
            if callable(apply_pose):
                new_pose: Dict[str, List[float]] = {}
                for joint, begin in self.initial_skeleton.items():
                    target = self.target_skeleton.get(joint, begin)
                    new_pose[joint] = [
                        begin[i] + (target[i] - begin[i]) * eased
                        for i in range(len(begin))
                    ]
                apply_pose(new_pose)

        # Mark complete when progress reaches 100%
        if progress >= 1.0:
            self.completed = True

    def is_active(self, current_time: float) -> bool:
        """Check if this step is currently executing."""
        return self.start_time <= current_time < self.start_time + self.duration


@dataclass
class Choreography:
    """
    Master animation orchestrator managing multiple concurrent steps across avatars.
    
    Features:
    - Concurrent step execution with frame-by-frame updates
    - Frame recording for playback/debugging
    - JSON export/import for choreography definitions
    - Performance optimizations: avatar caching, completed-step skipping
    """
    name: str = "Choreography"
    steps: List[ChoreographyStep] = field(default_factory=list)
    start_time: float = 0.0
    playing: bool = False
    current_time: float = 0.0
    recording: bool = False
    recorded_frames: List[Dict[str, object]] = field(default_factory=list)
    
    # --- OPTIMIZATION FIX ---
    # Avatar cache for O(1) lookup instead of O(n) iteration per frame
    _avatar_cache: Dict[str, object] = field(default_factory=dict, init=False, repr=False)
    
    # --- OPTIMIZATION FIX ---
    # Circular buffer for frame recording (limit memory in long sessions)
    MAX_RECORDED_FRAMES: int = 3600  # ~1 min at 60fps

    def add_step(self, step: ChoreographyStep) -> None:
        """Add and maintain temporal ordering of choreography steps."""
        self.steps.append(step)
        self.steps.sort(key=lambda s: s.start_time)

    def start(self, avatars: Iterable) -> None:
        """
        Begin choreography playback and initialize all active steps.
        
        Caches avatar lookup map for performance.
        """
        self.playing = True
        self.start_time = time.time()
        self.current_time = 0.0
        
        # --- PERFORMANCE FIX ---
        # Create avatar lookup dictionary once, reuse in update()
        self._avatar_cache = {getattr(a, "id", None): a for a in avatars}
        
        # Activate all steps
        for step in self.steps:
            avatar = self._avatar_cache.get(step.avatar_id)
            if avatar:
                step.activate(avatar)

    def stop(self) -> None:
        """Halt choreography playback and reset timer."""
        self.playing = False
        self.current_time = 0.0
        self._avatar_cache.clear()

    def update(self, avatars: Optional[Iterable] = None) -> None:
        """
        Advance animation state by one frame.
        
        Uses cached avatar map from start() if available.
        Can optionally accept new avatars to refresh cache.
        """
        if not self.playing:
            return

        self.current_time = time.time() - self.start_time
        
        # Refresh avatar cache if provided (for dynamic avatar rosters)
        if avatars is not None:
            self._avatar_cache = {getattr(a, "id", None): a for a in avatars}
        
        # --- PERFORMANCE FIX ---
        # Use cached avatar map for O(1) lookups
        for step in self.steps:
            avatar = self._avatar_cache.get(step.avatar_id)
            if avatar:
                step.update(avatar, self.current_time)

        # Record frame if telemetry is enabled
        if self.recording:
            self.record_frame()

    def record_frame(self) -> None:
        """
        Capture current state snapshot of all avatars for playback analysis.
        
        Uses circular buffer to prevent unbounded memory growth.
        """
        # --- OPTIMIZATION FIX ---
        # Implement circular buffer: evict oldest frame if at capacity
        if len(self.recorded_frames) >= self.MAX_RECORDED_FRAMES:
            self.recorded_frames.pop(0)
        
        frame = {
            "time": self.current_time,
            "avatars": [
                {
                    "id": getattr(avatar, "id", "unknown"),
                    "state": getattr(avatar, "get_sync_state", lambda: {})(),
                    "skeleton": getattr(avatar, "get_full_skeleton_data", lambda: {})(),
                }
                for avatar in self._avatar_cache.values()
            ],
        }
        self.recorded_frames.append(frame)

    def export_json(self, path: Path) -> None:
        """
        Export choreography definition (not runtime state) to JSON.
        
        Only saves animation targets and timing, not completed/initial states.
        This ensures re-imported choreographies start fresh.
        """
        # --- LOGICAL FIX ---
        # Define helper to serialize only the step *definition*, not runtime state.
        # This prevents saving "completed: true" or "initial_position" fields.
        def serialize_step(step: ChoreographyStep) -> Dict[str, object]:
            return {
                "avatar_id": step.avatar_id,
                "animation_type": step.animation_type,
                "start_time": step.start_time,
                "duration": step.duration,
                "target_position": step.target_position,
                "target_rotation": step.target_rotation,
                "target_skeleton": step.target_skeleton,
            }

        payload = {
            "name": self.name,
            "steps": [serialize_step(step) for step in self.steps],
            "recorded_frames": self.recorded_frames,
        }
        
        # --- SYNTAX FIX ---
        # Write valid JSON without stray braces
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    @classmethod
    def import_json(cls, path: Path) -> Choreography:
        """
        Load choreography definition from JSON.
        
        Reconstructs ChoreographyStep objects with fresh runtime state.
        """
        data = json.loads(path.read_text(encoding="utf-8"))
        choreography = cls(name=data.get("name", "Choreography"))
        
        for step_data in data.get("steps", []):
            step = ChoreographyStep(
                avatar_id=step_data["avatar_id"],
                animation_type=step_data["animation_type"],
                start_time=step_data["start_time"],
                duration=step_data["duration"],
                target_position=step_data.get("target_position", [0.0, 0.0, 0.0]),
                target_rotation=step_data.get("target_rotation", [0.0, 0.0, 0.0]),
                target_skeleton=step_data.get("target_skeleton", {}),
            )
            choreography.add_step(step)
        
        return choreography

    def get_active_steps(self, current_time: Optional[float] = None) -> List[ChoreographyStep]:
        """Return all steps currently active at the given time."""
        time_to_check = current_time if current_time is not None else self.current_time
        return [step for step in self.steps if step.is_active(time_to_check)]

    def get_completed_ratio(self) -> float:
        """Return percentage of steps completed (0.0 to 1.0)."""
        if not self.steps:
            return 1.0
        completed = sum(1 for step in self.steps if step.completed)
        return completed / len(self.steps)


# ==========================================
# EXAMPLE USAGE & TESTING
# ==========================================

if __name__ == "__main__":
    # Mock avatar class for demonstration
    class MockAvatar:
        def __init__(self, avatar_id: str):
            self.id = avatar_id
            self.position = [0.0, 0.0, 0.0]
            self.rotation = [0.0, 0.0, 0.0]
            self._pose_data = {}

        def get_full_skeleton_data(self) -> Dict[str, List[float]]:
            return {"head": [0.0, 0.0, 0.0], "spine": [0.0, 0.0, 0.0]}

        def apply_pose_data(self, pose: Dict[str, List[float]]) -> None:
            self._pose_data = pose

        def get_sync_state(self) -> Dict[str, object]:
            return {"position": self.position, "rotation": self.rotation}

    # Create avatars
    avatars = [MockAvatar(f"avatar_{i}") for i in range(3)]

    # Build choreography
    chore = Choreography(name="Example Dance")
    chore.add_step(
        ChoreographyStep(
            avatar_id="avatar_0",
            animation_type="move",
            start_time=0.0,
            duration=2.0,
            target_position=[5.0, 0.0, 0.0],
        )
    )
    chore.add_step(
        ChoreographyStep(
            avatar_id="avatar_1",
            animation_type="turn",
            start_time=0.5,
            duration=1.5,
            target_rotation=[0.0, 3.14, 0.0],
        )
    )

    # Play and record
    chore.recording = True
    chore.start(avatars)

    print("▶ Choreography playing...")
    print(f"Name: {chore.name}")
    print(f"Steps: {len(chore.steps)}")
    print(f"Avatar Cache Size: {len(chore._avatar_cache)}")

    # Simulate a few update cycles
    for i in range(5):
        time.sleep(0.5)
        chore.update()
        active = chore.get_active_steps()
        completion = chore.get_completed_ratio()
        print(f"[{i}] Time: {chore.current_time:.2f}s | Active: {len(active)} | Complete: {completion:.1%}")

    chore.stop()
    print(f"\n✓ Recorded {len(chore.recorded_frames)} frames")

    # Export
    output_path = Path("/tmp/choreography_export.json")
    chore.export_json(output_path)
    print(f"✓ Exported to {output_path}")

    # Re-import and verify
    chore_reloaded = Choreography.import_json(output_path)
    print(f"✓ Reloaded: {chore_reloaded.name} with {len(chore_reloaded.steps)} steps")
