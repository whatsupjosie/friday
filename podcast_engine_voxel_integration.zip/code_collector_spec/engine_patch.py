"""
engine_patch.py — Wire-in patch for distributed_engine_node_real.py
====================================================================
Rear View Foresight LLC

This file documents the EXACT changes needed to connect voxel_renderer.py
into distributed_engine_node_real.py.

There are two changes. Both are surgical. Nothing else changes.

CHANGE 1 — Add import at the top of distributed_engine_node_real.py
CHANGE 2 — Replace the voxel_render executor call in _process_work()

After applying these two changes, the distributed engine will use the
real voxel renderer (with LOD, lighting, .vox loading) instead of the
old VoxelRenderer.mesh() stub path.

──────────────────────────────────────────────────────────────────────────────
CHANGE 1: Import
──────────────────────────────────────────────────────────────────────────────

Find this block near the top of distributed_engine_node_real.py
(after the stdlib imports, before the class definitions):

    # === FIND THIS ===
    # (any existing import block near line 1-30)

Add ONE line anywhere in the import block:

    from voxel_renderer import render_voxel_work

If voxel_renderer.py is in a subdirectory (e.g. engines/):

    from engines.voxel_renderer import render_voxel_work

──────────────────────────────────────────────────────────────────────────────
CHANGE 2: Replace the voxel_render dispatch in _process_work()
──────────────────────────────────────────────────────────────────────────────

In DistributedEngineNode._process_work(), find this block (~line 1264):

    === BEFORE ===
    if work.work_type == "voxel_render":
        # CPU-bound: use process pool to bypass GIL
        result = await loop.run_in_executor(
            self._cpu_executor, VoxelRenderer.mesh, work.data
        )

    === AFTER ===
    if work.work_type == "voxel_render":
        # CPU-bound: use process pool to bypass GIL
        # render_voxel_work is module-level (picklable), handles LOD,
        # per-vertex lighting, and .vox file loading. Falls back to
        # empty mesh bytes on any error — never crashes the queue.
        result = await loop.run_in_executor(
            self._cpu_executor, render_voxel_work, work.data, work.metadata
        )

That's it. Two changes. The rest of the engine is untouched.

──────────────────────────────────────────────────────────────────────────────
HOW TO SUBMIT A VOXEL RENDER JOB WITH LIGHTING
──────────────────────────────────────────────────────────────────────────────

When creating a WorkUnit for a character render, populate metadata like this:

    from lighting_engine import LightingEngine

    lighting = LightingEngine()
    # optionally: lighting.set_preset("dramatic_interview")
    light_state = lighting.get_state().to_js_camel()

    work = WorkUnit(
        work_id      = str(uuid.uuid4()),
        work_type    = "voxel_render",
        data         = raw_vox_grid_bytes,   # or b"" if using vox_path
        metadata     = {
            "vox_path":       "/path/to/models/jeremy_cricket.vox",
            "camera_dist_m":  3.5,            # drives auto-LOD selection
            "light_state":    light_state,     # full LightState dict
        },
        priority     = 1,
        source_engine= self.engine_id,
        target_engine= self.engine_id,
    )
    await self.submit_work(work)

If you don't have a .vox file yet and want to use the raw grid in work.data:

    metadata = {
        "camera_dist_m": 3.5,
        "light_state":   light_state,
        # no "vox_path" → falls back to raw grid from work.data
    }

If you want to override LOD manually (e.g. force close-up for a cutscene):

    metadata = {
        "lod":        0,         # 0=full, 1=medium, 2=low, 3=billboard
        "vox_path":   "...",
        "light_state": light_state,
    }

──────────────────────────────────────────────────────────────────────────────
READING THE RESULT
──────────────────────────────────────────────────────────────────────────────

The result bytes from render_voxel_work are zlib-compressed and contain:

    4B   vertex_count   (uint32)
    4B   index_count    (uint32)
    V×12B vertices      (float32 x,y,z)
    V×12B normals       (float32 nx,ny,nz)
    V×12B colors        (float32 r,g,b)   ← NEW: lit colour per vertex
    I×4B  indices       (uint32)

Use the helper from voxel_renderer.py to decode it safely:

    from voxel_renderer import decode_mesh_bytes
    mesh = decode_mesh_bytes(work.result)
    # mesh["vertices"]  shape (N, 3) float32
    # mesh["normals"]   shape (N, 3) float32
    # mesh["colors"]    shape (N, 3) float32  — already lit, ready to render
    # mesh["indices"]   shape (M,)   uint32

──────────────────────────────────────────────────────────────────────────────
COMPATIBILITY NOTE
──────────────────────────────────────────────────────────────────────────────

The output format is a strict superset of the old VoxelRenderer output.
The only addition is the per-vertex colors section. Any consumer that only
reads vertices + normals + indices (as the old format specified) will still
work correctly — it simply stops reading before the colors section.

No consumer code needs to change unless it wants to use the lit colours.
"""

# This file is documentation. Nothing to run.
# Apply the two changes above manually or with your patch tool of choice.
