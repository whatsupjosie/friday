"""
test_integration.py — Integration tests for the voxel render pipeline
======================================================================
Tests the three components that were just written/wired together:
  1. voxel_renderer.py   — VoxModel loading, LOD, lighting, output format
  2. config.yaml         — All keys required by CharacterEngine are present
  3. engine_patch.py     — render_voxel_work is importable and picklable

Run with:
    python test_integration.py
    python -m pytest test_integration.py -v

All tests are self-contained. No external services required.
No .vox file required (uses synthetic grid data).
"""

from __future__ import annotations

import io
import pickle
import struct
import sys
import zlib
from pathlib import Path
from typing import Any, Dict

import numpy as np
import pytest

# ── Make sure local modules are importable ────────────────────────────────────
sys.path.insert(0, str(Path(__file__).parent))

from voxel_renderer import (
    VoxModel,
    LightParams,
    LOD_THRESHOLDS,
    LOD_TRIANGLE_BUDGET,
    LOD_STRIDE,
    dist_to_lod,
    apply_lighting,
    render_voxel_work,
    decode_mesh_bytes,
    _make_billboard,
    _build_mesh,
)


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def make_raw_grid(size: int = 16, fill: bool = True) -> bytes:
    """
    Create a minimal raw grid payload in the VoxelRenderer binary format:
        4B chunk_x (int32)
        4B chunk_y (int32)
        4B chunk_z (int32)
        4B size    (uint32)
        N  voxel_ids (uint8 × size³)
    """
    grid = np.zeros((size, size, size), dtype=np.uint8)
    if fill:
        # Solid 8×8×8 block in the centre (guaranteed exposed faces)
        half = size // 4
        s, e = half, size - half
        grid[s:e, s:e, s:e] = 1
    header = struct.pack("<iiII", 0, 0, 0, size)
    return header + grid.tobytes()


def make_metadata(
    lod: int = 0,
    camera_dist: float = 1.0,
    with_light: bool = True,
) -> Dict[str, Any]:
    meta: Dict[str, Any] = {
        "camera_dist_m": camera_dist,
        "lod": lod,
    }
    if with_light:
        meta["light_state"] = {
            "key_azimuth": -45.0,
            "key_elevation": 35.0,
            "key_kelvin": 5600.0,
            "key_intensity": 1.0,
            "fill_azimuth": 60.0,
            "fill_elevation": 20.0,
            "fill_kelvin": 6200.0,
            "fill_intensity": 0.35,
            "rim_intensity": 0.6,
            "rim_kelvin": 5600.0,
            "ambient_intensity": 0.25,
            "ambient_color": [0.12, 0.13, 0.18],
        }
    return meta


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: dist_to_lod
# ─────────────────────────────────────────────────────────────────────────────

class TestDistToLOD:

    def test_close_range_is_lod0(self):
        assert dist_to_lod(0.0) == 0
        assert dist_to_lod(1.0) == 0
        assert dist_to_lod(1.99) == 0

    def test_medium_range_is_lod1(self):
        assert dist_to_lod(2.0) == 1
        assert dist_to_lod(4.0) == 1
        assert dist_to_lod(5.99) == 1

    def test_wide_range_is_lod2(self):
        assert dist_to_lod(6.0) == 2
        assert dist_to_lod(10.0) == 2
        assert dist_to_lod(14.99) == 2

    def test_distant_is_lod3(self):
        assert dist_to_lod(15.0) == 3
        assert dist_to_lod(100.0) == 3
        assert dist_to_lod(1e9) == 3


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: VoxModel.from_raw_grid
# ─────────────────────────────────────────────────────────────────────────────

class TestVoxModelFromRaw:

    def test_basic_load(self):
        data = make_raw_grid(size=16)
        model = VoxModel.from_raw_grid(data)
        assert model.size_x == 16
        assert model.size_y == 16
        assert model.size_z == 16
        assert model.grid.shape == (16, 16, 16)
        assert model.palette.shape == (256, 4)

    def test_empty_grid_loads(self):
        grid = np.zeros((8, 8, 8), dtype=np.uint8)
        header = struct.pack("<iiII", 0, 0, 0, 8)
        data = header + grid.tobytes()
        model = VoxModel.from_raw_grid(data)
        assert np.all(model.grid == 0)

    def test_payload_too_short_raises(self):
        with pytest.raises(ValueError, match="too short"):
            VoxModel.from_raw_grid(b"\x00" * 10)

    def test_size_exceeds_max_raises(self):
        grid = np.zeros((65, 65, 65), dtype=np.uint8)
        header = struct.pack("<iiII", 0, 0, 0, 65)
        with pytest.raises(ValueError, match="size 65 > 64"):
            VoxModel.from_raw_grid(header + grid.tobytes())

    def test_palette_is_float(self):
        model = VoxModel.from_raw_grid(make_raw_grid())
        assert model.palette.dtype == np.float32
        assert model.palette.min() >= 0.0
        assert model.palette.max() <= 1.0


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: VoxModel.downsample
# ─────────────────────────────────────────────────────────────────────────────

class TestDownsample:

    def test_stride_1_is_identity(self):
        model = VoxModel.from_raw_grid(make_raw_grid(16))
        ds = model.downsample(1)
        assert ds.size_x == model.size_x
        np.testing.assert_array_equal(ds.grid, model.grid)

    def test_stride_2_halves_dimensions(self):
        model = VoxModel.from_raw_grid(make_raw_grid(16))
        ds = model.downsample(2)
        assert ds.size_x == 8
        assert ds.size_y == 8
        assert ds.size_z == 8

    def test_stride_4_quarters_dimensions(self):
        model = VoxModel.from_raw_grid(make_raw_grid(16))
        ds = model.downsample(4)
        assert ds.size_x == 4

    def test_solid_block_remains_solid_after_downsample(self):
        grid = np.ones((16, 16, 16), dtype=np.uint8)
        header = struct.pack("<iiII", 0, 0, 0, 16)
        model = VoxModel.from_raw_grid(header + grid.tobytes())
        ds = model.downsample(2)
        assert np.all(ds.grid != 0)


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: apply_lighting
# ─────────────────────────────────────────────────────────────────────────────

class TestApplyLighting:

    def test_output_shape(self):
        color  = np.array([0.8, 0.5, 0.3], dtype=np.float32)
        normal = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        light  = LightParams.default()
        result = apply_lighting(color, normal, light)
        assert result.shape == (3,)
        assert result.dtype == np.float32

    def test_output_in_range(self):
        for _ in range(20):
            color  = np.random.rand(3).astype(np.float32)
            normal = np.random.randn(3).astype(np.float32)
            normal /= np.linalg.norm(normal) + 1e-8
            light  = LightParams.default()
            result = apply_lighting(color, normal, light)
            assert np.all(result >= 0.0), "Negative colour component"
            assert np.all(result <= 1.0), "Colour component > 1"

    def test_zero_normal_doesnt_crash(self):
        color  = np.array([1.0, 1.0, 1.0], dtype=np.float32)
        normal = np.array([0.0, 0.0, 0.0], dtype=np.float32)
        light  = LightParams.default()
        result = apply_lighting(color, normal, light)
        assert result.shape == (3,)

    def test_light_from_dict(self):
        d = {
            "key_azimuth": -45.0, "key_elevation": 35.0, "key_kelvin": 5600.0,
            "key_intensity": 1.0, "fill_azimuth": 60.0, "fill_elevation": 20.0,
            "fill_kelvin": 6200.0, "fill_intensity": 0.35, "rim_intensity": 0.6,
            "rim_kelvin": 5600.0, "ambient_intensity": 0.25,
            "ambient_color": [0.12, 0.13, 0.18],
        }
        light  = LightParams.from_light_state_dict(d)
        color  = np.array([0.9, 0.7, 0.5], dtype=np.float32)
        normal = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        result = apply_lighting(color, normal, light)
        assert np.all(result >= 0.0) and np.all(result <= 1.0)

    def test_camelCase_light_dict(self):
        """LightState.to_js_camel() produces camelCase keys — must be handled."""
        d = {
            "keyAzimuth": -45.0, "keyElevation": 35.0, "keyKelvin": 5600.0,
            "keyIntensity": 1.0, "fillAzimuth": 60.0, "fillElevation": 20.0,
            "fillKelvin": 6200.0, "fillIntensity": 0.35, "rimIntensity": 0.6,
            "rimKelvin": 5600.0, "ambientIntensity": 0.25,
            "ambientColor": [0.12, 0.13, 0.18],
        }
        light = LightParams.from_light_state_dict(d)
        assert light.key_intensity == 1.0
        assert light.fill_intensity == 0.35


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: _build_mesh (internal, all LODs)
# ─────────────────────────────────────────────────────────────────────────────

class TestBuildMesh:

    def _decode(self, compressed: bytes):
        return decode_mesh_bytes(compressed)

    def test_all_air_returns_empty_mesh(self):
        grid = np.zeros((8, 8, 8), dtype=np.uint8)
        model = VoxModel(8, 8, 8, grid, VoxModel._generate_default_palette())
        light = LightParams.default()
        result = self._decode(_build_mesh(model, light, lod=0))
        assert result["vertices"].shape[0] == 0
        assert result["indices"].shape[0] == 0

    def test_solid_cube_has_faces(self):
        grid = np.ones((8, 8, 8), dtype=np.uint8)
        model = VoxModel(8, 8, 8, grid, VoxModel._generate_default_palette())
        light = LightParams.default()
        result = self._decode(_build_mesh(model, light, lod=0))
        # Only outer faces should be emitted: 6 faces × 4 corners × 8² quads each
        assert result["vertices"].shape[0] > 0
        assert result["indices"].shape[0] > 0

    def test_lod3_produces_billboard(self):
        model = VoxModel.from_raw_grid(make_raw_grid(16))
        light = LightParams.default()
        result = self._decode(_build_mesh(model, light, lod=3))
        # Billboard = 4 vertices, 6 indices (2 triangles)
        assert result["vertices"].shape[0] == 4
        assert result["indices"].shape[0] == 6

    def test_all_lods_produce_valid_output(self):
        for lod in range(4):
            model = VoxModel.from_raw_grid(make_raw_grid(16))
            light = LightParams.default()
            result = self._decode(_build_mesh(model, light, lod=lod))
            assert "vertices" in result
            assert "normals" in result
            assert "colors" in result
            assert "indices" in result
            n = result["vertices"].shape[0]
            assert result["normals"].shape == (n, 3)
            assert result["colors"].shape  == (n, 3)

    def test_colors_in_range(self):
        model = VoxModel.from_raw_grid(make_raw_grid(16))
        light = LightParams.default()
        result = self._decode(_build_mesh(model, light, lod=0))
        if result["colors"].shape[0] > 0:
            assert np.all(result["colors"] >= 0.0)
            assert np.all(result["colors"] <= 1.0)

    def test_lod1_fewer_triangles_than_lod0(self):
        model = VoxModel.from_raw_grid(make_raw_grid(16))
        light = LightParams.default()
        result0 = self._decode(_build_mesh(model, light, lod=0))
        result1 = self._decode(_build_mesh(model, light, lod=1))
        n_tri0 = result0["indices"].shape[0] // 3
        n_tri1 = result1["indices"].shape[0] // 3
        # LOD1 budget is lower, but LOD1 also uses stride=2 so fewer voxels
        # Just assert we didn't blow past the budget
        assert n_tri1 <= LOD_TRIANGLE_BUDGET[1] + 10  # +10 for rounding

    def test_chunk_offset_shifts_vertices(self):
        grid = np.zeros((4, 4, 4), dtype=np.uint8)
        grid[1, 1, 1] = 1
        model = VoxModel(4, 4, 4, grid, VoxModel._generate_default_palette())
        light = LightParams.default()
        r_no_offset  = decode_mesh_bytes(_build_mesh(model, light, 0, (0, 0, 0)))
        r_with_offset = decode_mesh_bytes(_build_mesh(model, light, 0, (10, 0, 0)))
        if r_no_offset["vertices"].shape[0] > 0 and r_with_offset["vertices"].shape[0] > 0:
            avg_x_no  = r_no_offset["vertices"][:, 0].mean()
            avg_x_yes = r_with_offset["vertices"][:, 0].mean()
            assert avg_x_yes > avg_x_no


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: render_voxel_work (the public entry point)
# ─────────────────────────────────────────────────────────────────────────────

class TestRenderVoxelWork:

    def test_returns_bytes(self):
        data   = make_raw_grid(16)
        meta   = make_metadata(lod=0)
        result = render_voxel_work(data, meta)
        assert isinstance(result, bytes)
        assert len(result) > 0

    def test_empty_data_returns_empty_mesh(self):
        result = render_voxel_work(b"", {})
        mesh   = decode_mesh_bytes(result)
        # No valid grid → empty model → empty mesh
        assert isinstance(result, bytes)

    def test_all_lods_via_camera_distance(self):
        distances = [1.0, 3.5, 8.0, 20.0]
        data = make_raw_grid(16)
        for dist in distances:
            meta   = make_metadata(camera_dist=dist, with_light=True)
            del meta["lod"]  # force auto-LOD
            result = render_voxel_work(data, meta)
            mesh   = decode_mesh_bytes(result)
            assert "vertices" in mesh

    def test_never_crashes_on_garbage_data(self):
        """render_voxel_work must NEVER raise — it's called in a process pool."""
        import os
        for _ in range(10):
            garbage = os.urandom(256)
            # Should return bytes, not raise
            result = render_voxel_work(garbage, {})
            assert isinstance(result, bytes)

    def test_output_is_valid_zlib(self):
        data   = make_raw_grid(16)
        result = render_voxel_work(data, make_metadata(lod=0))
        # decode_mesh_bytes internally calls zlib.decompress — will raise if invalid
        mesh = decode_mesh_bytes(result)
        assert mesh["vertices"].dtype == np.float32

    def test_is_picklable(self):
        """render_voxel_work must be picklable to be used in ProcessPoolExecutor."""
        pickled = pickle.dumps(render_voxel_work)
        fn = pickle.loads(pickled)
        assert callable(fn)

    def test_with_lighting(self):
        data   = make_raw_grid(16)
        meta   = make_metadata(lod=0, with_light=True)
        result = render_voxel_work(data, meta)
        mesh   = decode_mesh_bytes(result)
        if mesh["vertices"].shape[0] > 0:
            # Colors should be non-zero (lit) for a solid filled model
            assert np.any(mesh["colors"] > 0)

    def test_without_lighting_still_works(self):
        data   = make_raw_grid(16)
        meta   = make_metadata(lod=0, with_light=False)
        result = render_voxel_work(data, meta)
        mesh   = decode_mesh_bytes(result)
        assert "colors" in mesh


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: decode_mesh_bytes round-trip
# ─────────────────────────────────────────────────────────────────────────────

class TestDecodeMeshBytes:

    def test_empty_mesh_decodes(self):
        compressed = zlib.compress(struct.pack("<II", 0, 0))
        mesh = decode_mesh_bytes(compressed)
        assert mesh["vertices"].shape == (0, 3)
        assert mesh["indices"].shape  == (0,)
        assert mesh["colors"].shape   == (0, 3)

    def test_round_trip_preserves_data(self):
        # Build a tiny mesh manually and verify it survives the encode/decode
        n_verts = 4
        n_idx   = 6
        verts   = np.random.rand(n_verts, 3).astype(np.float32)
        norms   = np.random.rand(n_verts, 3).astype(np.float32)
        colors  = np.clip(np.random.rand(n_verts, 3), 0, 1).astype(np.float32)
        indices = np.array([0, 1, 2, 0, 2, 3], dtype=np.uint32)

        buf = io.BytesIO()
        buf.write(struct.pack("<II", n_verts, n_idx))
        buf.write(verts.tobytes())
        buf.write(norms.tobytes())
        buf.write(colors.tobytes())
        buf.write(indices.tobytes())
        compressed = zlib.compress(buf.getvalue())

        mesh = decode_mesh_bytes(compressed)
        np.testing.assert_allclose(mesh["vertices"], verts,   atol=1e-6)
        np.testing.assert_allclose(mesh["normals"],  norms,   atol=1e-6)
        np.testing.assert_allclose(mesh["colors"],   colors,  atol=1e-6)
        np.testing.assert_array_equal(mesh["indices"], indices)


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: config.yaml has all keys CharacterEngine expects
# ─────────────────────────────────────────────────────────────────────────────

class TestConfigYAML:

    @pytest.fixture
    def cfg(self):
        import yaml
        config_path = Path(__file__).parent / "config.yaml"
        assert config_path.exists(), "config.yaml not found in same directory as test"
        with open(config_path) as f:
            return yaml.safe_load(f)

    def test_top_level_sections_present(self, cfg):
        for key in ["system", "state_machine", "voxel", "prosody", "lighting", "engine"]:
            assert key in cfg, f"Missing top-level config key: {key}"

    def test_state_machine_keys(self, cfg):
        sm = cfg["state_machine"]
        required = [
            "complexity_care_threshold",
            "complexity_mandate_threshold",
            "velocity_care_threshold",
            "velocity_mandate_threshold",
            "lock_consecutive_signals",
            "cooldown_consecutive_signals",
            "stability_handshake_required",
            "stability_handshake_window_seconds",
            "dysregulation",
        ]
        for k in required:
            assert k in sm, f"state_machine missing key: {k}"

    def test_dysregulation_bands(self, cfg):
        dysreg = cfg["state_machine"]["dysregulation"]
        for band in ["light", "moderate", "heavy"]:
            assert band in dysreg
            bounds = dysreg[band]
            assert len(bounds) == 2
            assert bounds[0] < bounds[1]

    def test_system_default_mode_valid(self, cfg):
        valid_modes = {"AMBIENT", "ATTENTIVE", "CARE", "TOTAL_CARE_MANDATE"}
        assert cfg["system"]["default_mode"] in valid_modes

    def test_character_engine_can_load_config(self, cfg):
        """Smoke test: CharacterEngine.__init__ must not KeyError on config.yaml."""
        # We can't import CharacterEngine directly (asyncio.Lock, etc.) but we can
        # verify that every key the constructor touches is present.
        sm = cfg["state_machine"]
        _ = sm["complexity_care_threshold"]
        _ = sm["complexity_mandate_threshold"]
        _ = sm["velocity_care_threshold"]
        _ = sm["velocity_mandate_threshold"]
        _ = sm["lock_consecutive_signals"]
        _ = sm["cooldown_consecutive_signals"]
        _ = sm["stability_handshake_required"]
        _ = sm["stability_handshake_window_seconds"]
        dysreg = sm["dysregulation"]
        _ = dysreg["light"]
        _ = dysreg["moderate"]
        _ = dysreg["heavy"]
        _ = cfg["system"]["default_mode"]


# ─────────────────────────────────────────────────────────────────────────────
# ENTRYPOINT
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import subprocess
    result = subprocess.run(
        [sys.executable, "-m", "pytest", __file__, "-v", "--tb=short"],
        cwd=Path(__file__).parent,
    )
    sys.exit(result.returncode)
