# Code Collector → Memory Layer
## Complete Build Specification
**Rear View Foresight LLC**
**Authors: Josie Curtsey Cobbley + Claude**
**Spec Date: 2026-03-14**

---

> *"Close the laptop. Get in the car. Different app, same AI — it knows you."*

---

## What This Document Is

The technical ground truth before a single new line gets written.

Two things live here that didn't exist before:

1. **The SQLite schema** — designed for all four tiers right now, because you cannot migrate a sync protocol mid-flight across devices that are already syncing
2. **The Tier 1 completion checklist** — sequenced as actual build steps, with dependencies mapped, so nothing gets built in the wrong order

Nothing here breaks what you already built. Everything here extends it.

---

## Part 1: The SQLite Schema

### Design Principles

**Additive only.** Every new tier adds columns or tables. Nothing gets dropped or renamed. A Tier 1 device and a Tier 3 device can share the same index file — the Tier 1 device ignores columns it doesn't recognize. This is the only rule that matters for long-term sync correctness.

**Content hash is the key.** Not the filename. Not the path. The sha256 of the content itself. Two files with identical content are the same block, regardless of where they live or what they're named. This is what makes dedup, conflict detection, and reverse lookup all work from the same primitive.

**Rows are never deleted.** Only soft-archived. The version history is the product. Deleting a row is destroying a user's memory.

**FTS5 is built in from day one.** Not added later. The virtual table and triggers need to exist before data enters the DB, or you're re-indexing everything on upgrade.

---

### Database Location

```
~/.code-collector/index.db
```

Created on first Electron launch. Owned exclusively by `better-sqlite3` in the Electron main process. The HTTP server is the only write path — the bridge and extension never touch the DB file directly. The sync manager reads and exports it; it never writes concurrent with the server.

---

### Table: `captures`

One row per captured block. The core of everything.

```sql
CREATE TABLE IF NOT EXISTS captures (

  -- ── Identity ──────────────────────────────────────────────────────────────
  id                TEXT PRIMARY KEY,
  -- uuidv4, generated at capture time on the originating device.
  -- Never changes. Used as the merge key during sync.

  session_id        TEXT NOT NULL,
  -- Groups all blocks from one capture event (one POST to /collect).
  -- A single right-click capture of a directory produces one session_id
  -- for all files in that batch.

  -- ── Content ───────────────────────────────────────────────────────────────
  content           TEXT NOT NULL,
  -- The actual captured text. Code, prose, conversation turn, whatever.

  content_hash      TEXT NOT NULL,
  -- sha256(content). The dedup key. If two captures have the same hash,
  -- they captured the same thing. Used for conflict detection and reverse lookup.

  language          TEXT,
  -- Programming language (tier 1-3) or content subtype (tier 4).
  -- e.g. 'python', 'javascript', 'markdown', 'sql'

  content_type      TEXT NOT NULL DEFAULT 'code',
  -- The extractor family that produced this block.
  -- Tier 1-3: always 'code'
  -- Tier 4: 'code' | 'document' | 'conversation' | 'image' | 'data' | 'legal'
  -- Never change a stored value. If the type classification improves, add a new capture.

  -- ── Provenance ────────────────────────────────────────────────────────────
  source_url        TEXT,
  -- Where the capture came from.
  -- Extension: the AI chat URL (e.g. https://claude.ai/chat/abc123)
  -- Bridge: file:///absolute/path/to/file.py
  -- Dir mode: file:///absolute/path/to/directory/

  source_title      TEXT,
  -- Human-readable source label.
  -- Extension: 'Claude', 'ChatGPT', 'Gemini', 'Copilot', etc. (detected from URL)
  -- Bridge: the filename stem, e.g. 'main'

  detected_filename TEXT,
  -- Filename as extracted from context.
  -- Extension: parsed from the code block or nearby text in the chat
  -- Bridge: the actual filename

  file_path         TEXT,
  -- Resolved absolute path on disk. Null if extension-only (no OS bridge hit).
  -- Populated by /context pre-flight enrichment when the OS bridge has seen the file.

  git_root          TEXT,
  -- Absolute path to the git repo root for this file, if known.

  -- ── Context Window ────────────────────────────────────────────────────────
  context_before    TEXT,
  -- Extension: text preceding the code block in the chat
  -- Bridge: content of nearest README (walking up from file to repo root)

  context_after     TEXT,
  -- Extension: text following the code block in the chat
  -- Bridge: output of `git log --oneline -5` for this file

  purpose_hint      TEXT,
  -- Top docstring or first meaningful block comment.
  -- The one-line answer to "what does this file/function do?"

  context_window    TEXT,
  -- context_before + '\n\n' + context_after, combined for FTS indexing.
  -- Computed at insert time. Do not update independently.

  -- ── Capture Metadata ──────────────────────────────────────────────────────
  captured_at       TEXT NOT NULL,
  -- ISO 8601 timestamp, UTC. Set at capture time on originating device.
  -- Never updated after insert.

  target            TEXT NOT NULL DEFAULT 'primary',
  -- Routing destination: 'primary' | 'archive' | 'both' | 'cloud'
  -- Matches the routing vocabulary in the extension and bridge.

  capture_source    TEXT NOT NULL DEFAULT 'extension',
  -- What triggered this capture:
  -- 'extension'  — browser extension captured from AI chat
  -- 'bridge'     — OS bridge (right-click or CLI)
  -- 'watch'      — file watcher auto-capture (tier 2+)
  -- 'api'        — direct API call (future)

  platform          TEXT,
  -- Runtime that sent the capture:
  -- 'chrome' | 'firefox' | 'safari' | 'bridge_macos' | 'bridge_windows' | 'bridge_linux'

  -- ── Version Tracking (Tier 2) ─────────────────────────────────────────────
  version_number    INTEGER NOT NULL DEFAULT 1,
  -- Monotonically increasing per (detected_filename, file_path).
  -- Computed at insert: SELECT MAX(version_number) + 1 FROM captures
  --   WHERE detected_filename = ? AND (file_path = ? OR file_path IS NULL)
  -- Starts at 1 for the first capture of any given file.

  superseded_by     TEXT REFERENCES captures(id),
  -- NULL = this is the current version.
  -- Set when a newer capture of the same file is inserted.
  -- Enables walking the version chain forward and backward.

  is_current        INTEGER NOT NULL DEFAULT 1,
  -- Denormalized flag: 1 = latest version of this file, 0 = historical.
  -- Updated atomically with superseded_by when a new version is inserted.
  -- Index on (is_current, detected_filename) makes "get current version" a
  -- single fast lookup.

  -- ── Cross-Device Sync (Tier 3) ────────────────────────────────────────────
  origin_device     TEXT,
  -- device_id of the machine where this capture was first created.
  -- Set at insert on the originating device. Never changes.
  -- Populated from ~/.code-collector.json: { "device_id": "josie-macbook-pro" }

  sync_vector       TEXT,
  -- JSON object: logical clock per device.
  -- e.g. {"josie-macbook": 42, "josie-phone": 7}
  -- Used for conflict resolution: higher vector = more recent on that device.
  -- Last-write-wins per id. Merge strategy: union of all known ids.

  synced_at         TEXT,
  -- ISO 8601 timestamp of last sync write for this row.
  -- NULL = originated here, not yet synced to any other device.

  -- ── Soft Delete ───────────────────────────────────────────────────────────
  archived_at       TEXT
  -- NULL = active. ISO 8601 timestamp = user-archived.
  -- Never hard-delete. The history is the product.
);

-- ── Indexes ───────────────────────────────────────────────────────────────────

-- Core lookups (used by /context endpoint, pre-flight enrichment, conflict detection)
CREATE INDEX IF NOT EXISTS idx_cap_filename
  ON captures(detected_filename) WHERE archived_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_cap_hash
  ON captures(content_hash) WHERE archived_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_cap_filepath
  ON captures(file_path) WHERE file_path IS NOT NULL AND archived_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_cap_session
  ON captures(session_id);

CREATE INDEX IF NOT EXISTS idx_cap_current
  ON captures(is_current, detected_filename) WHERE archived_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_cap_captured_at
  ON captures(captured_at DESC);

-- Tier 3: sync queries
CREATE INDEX IF NOT EXISTS idx_cap_origin_device
  ON captures(origin_device);

CREATE INDEX IF NOT EXISTS idx_cap_synced_at
  ON captures(synced_at DESC);
```

---

### Table: `known_files`

One row per file ever seen on disk by the OS bridge. The OS bridge's memory.

```sql
CREATE TABLE IF NOT EXISTS known_files (

  -- ── Identity ──────────────────────────────────────────────────────────────
  file_path         TEXT PRIMARY KEY,
  -- Absolute path. e.g. /Users/josie/projects/app/main.py
  -- Canonical form: resolved symlinks, no trailing slash.

  -- ── Current State ─────────────────────────────────────────────────────────
  content_hash      TEXT NOT NULL,
  -- sha256 of file content at last_seen. The ground truth for conflict detection.

  last_seen         TEXT NOT NULL,
  -- ISO 8601 timestamp of last OS bridge capture of this file.

  last_modified     TEXT,
  -- File system mtime at last_seen. Used to detect whether the file changed
  -- since we last saw it without re-hashing (mtime check is fast; hash is slow).

  file_size_bytes   INTEGER,

  -- ── Project Context ───────────────────────────────────────────────────────
  git_root          TEXT,
  -- Absolute path to git repo root. Populated by bridge's cached git detection.

  git_branch        TEXT,
  -- Branch name at time of last_seen.

  readme_path       TEXT,
  -- Absolute path to nearest README (walking up from file to git_root).

  readme_hash       TEXT,
  -- sha256 of README at last_seen. Used to detect README changes without re-reading.

  -- ── Conflict State (Tier 2) ───────────────────────────────────────────────
  last_capture_id   TEXT REFERENCES captures(id),
  -- id of the most recent capture row for this file.
  -- Used to look up the captured version for diff/conflict display.

  is_stale          INTEGER NOT NULL DEFAULT 0,
  -- 0 = disk content_hash matches last_capture_id's content_hash (in sync)
  -- 1 = they differ (disk has changed since last capture, or AI produced different code)
  -- Recomputed on every new capture and every OS bridge scan.

  stale_since       TEXT,
  -- ISO 8601 timestamp when is_stale first became 1.
  -- NULL when is_stale = 0.

  -- ── Sync (Tier 3) ─────────────────────────────────────────────────────────
  origin_device     TEXT
  -- device_id of machine that last wrote this row.
);

CREATE INDEX IF NOT EXISTS idx_kf_git_root
  ON known_files(git_root);

CREATE INDEX IF NOT EXISTS idx_kf_stale
  ON known_files(is_stale) WHERE is_stale = 1;

CREATE INDEX IF NOT EXISTS idx_kf_last_seen
  ON known_files(last_seen DESC);
```

---

### Table: `sessions`

One row per capture session. Lightweight — just the envelope.

```sql
CREATE TABLE IF NOT EXISTS sessions (
  id              TEXT PRIMARY KEY,         -- matches session_id in captures
  started_at      TEXT NOT NULL,
  ended_at        TEXT,                     -- NULL = in progress
  source_url      TEXT,                     -- top-level URL for this session
  source_title    TEXT,                     -- 'Claude', 'ChatGPT', etc.
  capture_source  TEXT NOT NULL DEFAULT 'extension',
  block_count     INTEGER NOT NULL DEFAULT 0,
  device_id       TEXT,

  -- Tier 2: Session summary
  files_touched   TEXT,                     -- JSON array of detected_filenames
  summary         TEXT                      -- user-editable or AI-generated session note
);
```

---

### Table: `devices` (Tier 3)

One row per device that has ever participated in sync.

```sql
CREATE TABLE IF NOT EXISTS devices (
  device_id       TEXT PRIMARY KEY,         -- set in ~/.code-collector.json
  display_name    TEXT,                     -- 'Josie MacBook Pro', 'Josie iPhone', etc.
  platform        TEXT,                     -- 'macos' | 'windows' | 'linux' | 'ios' | 'android'
  first_seen      TEXT NOT NULL,
  last_seen       TEXT NOT NULL,
  last_sync       TEXT                      -- timestamp of last successful sync from this device
);
```

---

### FTS5 Virtual Table

```sql
-- Full-text search across all captured content.
-- Populated and kept in sync by triggers (see below).

CREATE VIRTUAL TABLE IF NOT EXISTS captures_fts USING fts5(
  content,
  purpose_hint,
  context_window,
  detected_filename,
  source_title,
  content=captures,
  content_rowid=rowid
);

-- Keep FTS in sync with captures table
CREATE TRIGGER IF NOT EXISTS captures_fts_insert
  AFTER INSERT ON captures BEGIN
    INSERT INTO captures_fts(rowid, content, purpose_hint, context_window, detected_filename, source_title)
    VALUES (new.rowid, new.content, new.purpose_hint, new.context_window, new.detected_filename, new.source_title);
  END;

CREATE TRIGGER IF NOT EXISTS captures_fts_delete
  AFTER DELETE ON captures BEGIN
    INSERT INTO captures_fts(captures_fts, rowid, content, purpose_hint, context_window, detected_filename, source_title)
    VALUES ('delete', old.rowid, old.content, old.purpose_hint, old.context_window, old.detected_filename, old.source_title);
  END;

CREATE TRIGGER IF NOT EXISTS captures_fts_update
  AFTER UPDATE ON captures BEGIN
    INSERT INTO captures_fts(captures_fts, rowid, content, purpose_hint, context_window, detected_filename, source_title)
    VALUES ('delete', old.rowid, old.content, old.purpose_hint, old.context_window, old.detected_filename, old.source_title);
    INSERT INTO captures_fts(rowid, content, purpose_hint, context_window, detected_filename, source_title)
    VALUES (new.rowid, new.content, new.purpose_hint, new.context_window, new.detected_filename, new.source_title);
  END;
```

---

### Schema Migration Strategy

The DB file carries its own version number via SQLite's `PRAGMA user_version`.

```sql
PRAGMA user_version = 1;   -- Tier 1 schema
-- user_version = 2        -- Tier 2 additions
-- user_version = 3        -- Tier 3 additions
-- user_version = 4        -- Tier 4 additions
```

Electron checks `user_version` on startup. Migrations are additive SQL (`ALTER TABLE ADD COLUMN IF NOT EXISTS`, new tables). A DB at version 1 opened by a version 3 binary runs the version 1→2 and 2→3 migrations automatically on startup. A DB at version 3 opened by a version 1 binary is ignored (the binary tells the user to upgrade).

**Rule:** Every migration script is committed to the repo and versioned. No inline migration strings in application code.

---

## Part 2: Tier 1 Completion — Sequenced Build Steps

**Current state of Tier 1:** ~85% complete. What exists: browser extension (Chrome/Firefox), Electron tray app (HTTP server, routing, settings UI), OS bridge (collector_bridge.py v5), cloud folder routing, ~/.code-collector.json config file.

**What's left, in the order it must be built:**

---

### Step 1 — DB initialization in Electron (main.js)
**Depends on:** nothing
**Blocks:** everything else

Install `better-sqlite3`. On app startup, before the HTTP server starts:

1. Ensure `~/.code-collector/` directory exists
2. Open `index.db` with `better-sqlite3`
3. Run `PRAGMA journal_mode=WAL` (required for sync — allows concurrent reads during write)
4. Run `PRAGMA foreign_keys=ON`
5. Execute the full schema SQL above (all `CREATE TABLE IF NOT EXISTS`, all indexes, all triggers)
6. Check `PRAGMA user_version`. If 0 (new DB), set to 1. If > current binary version, refuse to start and tell user to upgrade.

The DB handle is a module-level singleton. It is never closed while the app is running except on clean quit.

**Done when:** App starts, `~/.code-collector/index.db` exists with correct schema, WAL mode confirmed.

---

### Step 2 — Write captures to DB on every POST /collect
**Depends on:** Step 1
**Blocks:** Steps 3, 4

When the server receives a valid POST to `/collect`, after routing to the target folder (existing behavior, unchanged), also write to the DB:

For each block in the payload