class FriendMemory:
    """Values, goals, projects, worries, victories, lessons."""
    pass
