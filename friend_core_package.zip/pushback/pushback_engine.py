class PushbackEngine:
    """Respectfully challenges assumptions without insisting."""
    pass
