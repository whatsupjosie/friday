# Investigator Mode

This package contains the heavier research-oriented systems:
- evidence_layer.py
- contradiction_engine.py
- theory_graph.py
- predictive_insight.py

These are tools, not the center of the companion.
