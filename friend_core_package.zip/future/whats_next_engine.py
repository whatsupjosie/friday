class WhatsNextEngine:
    """Accepts what happened and focuses on the next step."""
    pass
