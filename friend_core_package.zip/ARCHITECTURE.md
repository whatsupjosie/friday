# Friend Core Architecture

Conversation
  -> Memory
  -> Insight
  -> Pushback
  -> Encouragement
  -> What's Next

Investigator Mode is optional and can be activated when deeper analysis is useful.
