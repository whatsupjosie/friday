# CricketMobile Standalone Companion
(c) 2026 Rear View Foresight LLC

## Installation
1. Install Python 3.10+
2. pip install -r requirements.txt
3. python main.py

## Android Build
1. Install Flet CLI: `pip install flet`
2. Run `flet build apk`

## Windows Build
1. Run `pyinstaller --onefile main.py`
