import flet as ft
# This is your standalone entry point
def main(page: ft.Page):
    page.title = "Jeremy Cricket Companion"
    page.add(ft.Text("Welcome to your private companion."))
ft.app(target=main)
